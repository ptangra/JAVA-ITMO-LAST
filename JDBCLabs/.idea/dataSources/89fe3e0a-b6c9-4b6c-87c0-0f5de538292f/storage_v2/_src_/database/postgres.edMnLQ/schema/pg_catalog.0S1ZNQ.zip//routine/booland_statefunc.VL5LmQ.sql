CREATE FUNCTION booland_statefunc(boolean, boolean)
  RETURNS boolean
AS $$
booland_statefunc
$$;

