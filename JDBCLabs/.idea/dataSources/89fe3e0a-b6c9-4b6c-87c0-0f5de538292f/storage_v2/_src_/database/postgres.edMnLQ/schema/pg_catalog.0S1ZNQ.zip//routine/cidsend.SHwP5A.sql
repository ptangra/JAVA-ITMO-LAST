CREATE FUNCTION cidsend(cid)
  RETURNS bytea
AS $$
cidsend
$$;

