CREATE FUNCTION bit_length(bytea)
  RETURNS integer
AS $$
select pg_catalog.octet_length($1) * 8
$$;

