CREATE FUNCTION circle_overabove(circle, circle)
  RETURNS boolean
AS $$
circle_overabove
$$;

