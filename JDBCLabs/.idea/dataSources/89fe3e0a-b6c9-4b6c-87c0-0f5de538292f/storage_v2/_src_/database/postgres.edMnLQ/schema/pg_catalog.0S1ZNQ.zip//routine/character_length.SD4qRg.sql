CREATE FUNCTION character_length(text)
  RETURNS integer
AS $$
textlen
$$;

