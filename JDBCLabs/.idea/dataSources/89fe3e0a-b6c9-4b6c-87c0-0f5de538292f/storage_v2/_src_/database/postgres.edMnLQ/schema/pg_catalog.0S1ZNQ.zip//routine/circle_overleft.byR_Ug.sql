CREATE FUNCTION circle_overleft(circle, circle)
  RETURNS boolean
AS $$
circle_overleft
$$;

