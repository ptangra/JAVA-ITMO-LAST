CREATE FUNCTION charsend("char")
  RETURNS bytea
AS $$
charsend
$$;

