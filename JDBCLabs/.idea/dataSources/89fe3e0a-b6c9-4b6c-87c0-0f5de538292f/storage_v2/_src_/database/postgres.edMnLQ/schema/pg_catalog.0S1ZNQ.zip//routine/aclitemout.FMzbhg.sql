CREATE FUNCTION aclitemout(aclitem)
  RETURNS cstring
AS $$
aclitemout
$$;

