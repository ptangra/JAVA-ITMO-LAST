CREATE FUNCTION circle_contain(circle, circle)
  RETURNS boolean
AS $$
circle_contain
$$;

