CREATE FUNCTION bpchar_pattern_lt(character, character)
  RETURNS boolean
AS $$
bpchar_pattern_lt
$$;

