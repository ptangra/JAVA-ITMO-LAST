CREATE FUNCTION bit_in(cstring, oid, integer)
  RETURNS bit
AS $$
bit_in
$$;

