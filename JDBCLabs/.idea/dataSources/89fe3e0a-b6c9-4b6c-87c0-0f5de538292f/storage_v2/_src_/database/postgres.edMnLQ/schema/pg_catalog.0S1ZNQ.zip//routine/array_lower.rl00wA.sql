CREATE FUNCTION array_lower(anyarray, integer)
  RETURNS integer
AS $$
array_lower
$$;

