CREATE FUNCTION ceil(double precision)
  RETURNS double precision
AS $$
dceil
$$;

