CREATE FUNCTION circle_add_pt(circle, point)
  RETURNS circle
AS $$
circle_add_pt
$$;

