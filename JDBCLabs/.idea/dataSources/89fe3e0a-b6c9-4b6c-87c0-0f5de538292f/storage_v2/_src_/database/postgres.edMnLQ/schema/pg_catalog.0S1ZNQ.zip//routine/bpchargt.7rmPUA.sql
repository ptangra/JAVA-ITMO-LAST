CREATE FUNCTION bpchargt(character, character)
  RETURNS boolean
AS $$
bpchargt
$$;

