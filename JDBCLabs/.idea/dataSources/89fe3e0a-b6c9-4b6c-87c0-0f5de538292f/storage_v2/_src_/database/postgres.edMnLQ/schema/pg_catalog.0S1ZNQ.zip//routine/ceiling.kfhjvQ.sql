CREATE FUNCTION ceiling(double precision)
  RETURNS double precision
AS $$
dceil
$$;

