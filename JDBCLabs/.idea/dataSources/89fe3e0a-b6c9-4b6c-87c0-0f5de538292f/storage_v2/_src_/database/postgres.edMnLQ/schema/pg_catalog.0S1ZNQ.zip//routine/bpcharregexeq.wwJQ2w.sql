CREATE FUNCTION bpcharregexeq(character, text)
  RETURNS boolean
AS $$
textregexeq
$$;

