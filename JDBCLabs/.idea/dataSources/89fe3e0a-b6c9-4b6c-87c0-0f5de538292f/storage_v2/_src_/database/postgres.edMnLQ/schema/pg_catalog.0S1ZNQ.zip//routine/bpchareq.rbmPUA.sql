CREATE FUNCTION bpchareq(character, character)
  RETURNS boolean
AS $$
bpchareq
$$;

