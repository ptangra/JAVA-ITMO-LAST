CREATE FUNCTION aclinsert(aclitem[], aclitem)
  RETURNS aclitem[]
AS $$
aclinsert
$$;

