CREATE FUNCTION cash_in(cstring)
  RETURNS money
AS $$
cash_in
$$;

