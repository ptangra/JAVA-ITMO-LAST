CREATE FUNCTION cashsmaller(money, money)
  RETURNS money
AS $$
cashsmaller
$$;

