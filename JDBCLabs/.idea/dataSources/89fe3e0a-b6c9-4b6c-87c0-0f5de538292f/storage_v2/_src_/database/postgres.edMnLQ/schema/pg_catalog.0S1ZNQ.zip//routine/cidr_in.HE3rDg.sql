CREATE FUNCTION cidr_in(cstring)
  RETURNS cidr
AS $$
cidr_in
$$;

