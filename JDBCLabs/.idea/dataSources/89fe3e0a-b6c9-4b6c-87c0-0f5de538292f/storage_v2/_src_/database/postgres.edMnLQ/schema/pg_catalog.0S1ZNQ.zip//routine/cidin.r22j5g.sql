CREATE FUNCTION cidin(cstring)
  RETURNS cid
AS $$
cidin
$$;

