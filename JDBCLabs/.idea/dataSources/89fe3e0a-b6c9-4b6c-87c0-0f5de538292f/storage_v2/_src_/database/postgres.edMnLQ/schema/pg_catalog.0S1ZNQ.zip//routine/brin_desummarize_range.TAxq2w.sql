CREATE FUNCTION brin_desummarize_range(regclass, bigint)
  RETURNS void
AS $$
brin_desummarize_range
$$;

