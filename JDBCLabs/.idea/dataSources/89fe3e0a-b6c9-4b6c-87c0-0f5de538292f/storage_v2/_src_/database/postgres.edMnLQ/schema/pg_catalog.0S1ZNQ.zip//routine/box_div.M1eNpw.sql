CREATE FUNCTION box_div(box, point)
  RETURNS box
AS $$
box_div
$$;

