CREATE FUNCTION circle_contain_pt(circle, point)
  RETURNS boolean
AS $$
circle_contain_pt
$$;

