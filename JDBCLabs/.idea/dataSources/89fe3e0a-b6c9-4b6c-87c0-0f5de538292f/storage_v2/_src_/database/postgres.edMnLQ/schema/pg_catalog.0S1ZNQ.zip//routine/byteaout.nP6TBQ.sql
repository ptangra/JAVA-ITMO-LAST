CREATE FUNCTION byteaout(bytea)
  RETURNS cstring
AS $$
byteaout
$$;

