CREATE FUNCTION cidout(cid)
  RETURNS cstring
AS $$
cidout
$$;

