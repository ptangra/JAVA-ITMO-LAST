CREATE FUNCTION bit_send(bit)
  RETURNS bytea
AS $$
bit_send
$$;

