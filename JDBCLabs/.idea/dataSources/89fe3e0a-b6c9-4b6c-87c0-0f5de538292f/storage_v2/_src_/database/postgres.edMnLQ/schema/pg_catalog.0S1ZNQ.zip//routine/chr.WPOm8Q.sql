CREATE FUNCTION chr(integer)
  RETURNS text
AS $$
chr
$$;

