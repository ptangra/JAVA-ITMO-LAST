CREATE FUNCTION byteasend(bytea)
  RETURNS bytea
AS $$
byteasend
$$;

