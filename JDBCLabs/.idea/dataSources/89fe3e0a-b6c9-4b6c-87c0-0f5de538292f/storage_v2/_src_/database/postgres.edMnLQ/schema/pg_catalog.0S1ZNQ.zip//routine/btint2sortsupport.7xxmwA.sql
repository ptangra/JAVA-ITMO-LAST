CREATE FUNCTION btint2sortsupport(internal)
  RETURNS void
AS $$
btint2sortsupport
$$;

