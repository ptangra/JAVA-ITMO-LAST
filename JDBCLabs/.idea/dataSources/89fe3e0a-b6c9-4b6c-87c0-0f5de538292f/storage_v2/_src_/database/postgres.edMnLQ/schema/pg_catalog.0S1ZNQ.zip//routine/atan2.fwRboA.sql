CREATE FUNCTION atan2(double precision, double precision)
  RETURNS double precision
AS $$
datan2
$$;

