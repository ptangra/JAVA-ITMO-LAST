CREATE FUNCTION bpcharnlike(character, text)
  RETURNS boolean
AS $$
textnlike
$$;

