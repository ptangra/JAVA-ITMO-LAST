CREATE FUNCTION bpchar_pattern_le(character, character)
  RETURNS boolean
AS $$
bpchar_pattern_le
$$;

