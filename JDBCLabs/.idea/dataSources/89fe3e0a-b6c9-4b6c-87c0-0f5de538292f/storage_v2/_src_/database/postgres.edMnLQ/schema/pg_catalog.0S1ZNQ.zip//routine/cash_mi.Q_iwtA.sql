CREATE FUNCTION cash_mi(money, money)
  RETURNS money
AS $$
cash_mi
$$;

