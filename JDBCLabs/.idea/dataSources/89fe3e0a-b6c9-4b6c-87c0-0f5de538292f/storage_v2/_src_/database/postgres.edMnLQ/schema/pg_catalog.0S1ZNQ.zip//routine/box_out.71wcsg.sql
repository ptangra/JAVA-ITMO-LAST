CREATE FUNCTION box_out(box)
  RETURNS cstring
AS $$
box_out
$$;

