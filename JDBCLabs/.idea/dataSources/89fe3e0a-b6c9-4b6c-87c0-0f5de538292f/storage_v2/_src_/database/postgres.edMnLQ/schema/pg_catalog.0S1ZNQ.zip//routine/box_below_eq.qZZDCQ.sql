CREATE FUNCTION box_below_eq(box, box)
  RETURNS boolean
AS $$
box_below_eq
$$;

