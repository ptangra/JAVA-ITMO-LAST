CREATE FUNCTION anyarray_send(anyarray)
  RETURNS bytea
AS $$
anyarray_send
$$;

