CREATE FUNCTION cash_cmp(money, money)
  RETURNS integer
AS $$
cash_cmp
$$;

