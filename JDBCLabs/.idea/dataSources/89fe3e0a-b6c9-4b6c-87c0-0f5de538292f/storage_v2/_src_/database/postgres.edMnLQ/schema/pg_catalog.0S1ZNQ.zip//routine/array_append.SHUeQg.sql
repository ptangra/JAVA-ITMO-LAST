CREATE FUNCTION array_append(anyarray, anyelement)
  RETURNS anyarray
AS $$
array_append
$$;

