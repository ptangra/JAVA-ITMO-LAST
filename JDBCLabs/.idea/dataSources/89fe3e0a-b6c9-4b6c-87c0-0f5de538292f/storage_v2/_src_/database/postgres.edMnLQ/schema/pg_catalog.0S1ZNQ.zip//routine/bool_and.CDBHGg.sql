CREATE FUNCTION bool_and(boolean)
  RETURNS boolean
AS $$
aggregate_dummy
$$;

