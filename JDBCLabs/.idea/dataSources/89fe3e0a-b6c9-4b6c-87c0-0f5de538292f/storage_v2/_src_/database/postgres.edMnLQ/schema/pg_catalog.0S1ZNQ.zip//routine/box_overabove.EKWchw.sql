CREATE FUNCTION box_overabove(box, box)
  RETURNS boolean
AS $$
box_overabove
$$;

