CREATE FUNCTION "RI_FKey_setdefault_del"()
  RETURNS trigger
AS $$
RI_FKey_setdefault_del
$$;

