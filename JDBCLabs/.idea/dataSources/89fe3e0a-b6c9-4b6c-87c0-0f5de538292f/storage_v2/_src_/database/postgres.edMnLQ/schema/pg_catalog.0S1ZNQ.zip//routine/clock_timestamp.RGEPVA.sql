CREATE FUNCTION clock_timestamp()
  RETURNS timestamp with time zone
AS $$
clock_timestamp
$$;

