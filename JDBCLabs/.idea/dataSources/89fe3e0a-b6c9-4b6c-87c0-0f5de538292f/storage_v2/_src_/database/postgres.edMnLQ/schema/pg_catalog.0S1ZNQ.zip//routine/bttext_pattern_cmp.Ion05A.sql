CREATE FUNCTION bttext_pattern_cmp(text, text)
  RETURNS integer
AS $$
bttext_pattern_cmp
$$;

