CREATE FUNCTION btint82cmp(bigint, smallint)
  RETURNS integer
AS $$
btint82cmp
$$;

