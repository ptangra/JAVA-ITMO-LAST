CREATE FUNCTION bitnot(bit)
  RETURNS bit
AS $$
bitnot
$$;

