CREATE FUNCTION bitlt(bit, bit)
  RETURNS boolean
AS $$
bitlt
$$;

