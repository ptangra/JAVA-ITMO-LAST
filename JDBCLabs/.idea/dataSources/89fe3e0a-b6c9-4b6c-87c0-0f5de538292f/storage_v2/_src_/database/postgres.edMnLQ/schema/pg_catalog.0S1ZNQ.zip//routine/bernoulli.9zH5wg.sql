CREATE FUNCTION bernoulli(internal)
  RETURNS tsm_handler
AS $$
tsm_bernoulli_handler
$$;

