CREATE FUNCTION "RI_FKey_noaction_del"()
  RETURNS trigger
AS $$
RI_FKey_noaction_del
$$;

