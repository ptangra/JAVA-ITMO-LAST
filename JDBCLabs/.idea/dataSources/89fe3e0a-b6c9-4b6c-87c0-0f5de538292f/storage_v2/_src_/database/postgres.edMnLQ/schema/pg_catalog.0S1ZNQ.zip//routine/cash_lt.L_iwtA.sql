CREATE FUNCTION cash_lt(money, money)
  RETURNS boolean
AS $$
cash_lt
$$;

