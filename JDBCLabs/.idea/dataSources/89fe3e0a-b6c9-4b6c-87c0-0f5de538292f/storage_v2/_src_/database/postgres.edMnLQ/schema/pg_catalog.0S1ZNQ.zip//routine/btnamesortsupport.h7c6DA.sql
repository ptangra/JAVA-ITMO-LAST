CREATE FUNCTION btnamesortsupport(internal)
  RETURNS void
AS $$
btnamesortsupport
$$;

