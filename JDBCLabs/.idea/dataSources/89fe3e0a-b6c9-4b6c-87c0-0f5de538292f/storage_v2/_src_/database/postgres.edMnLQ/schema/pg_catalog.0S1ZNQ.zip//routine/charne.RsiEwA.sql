CREATE FUNCTION charne("char", "char")
  RETURNS boolean
AS $$
charne
$$;

