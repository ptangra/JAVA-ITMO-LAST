CREATE FUNCTION bytearecv(internal)
  RETURNS bytea
AS $$
bytearecv
$$;

