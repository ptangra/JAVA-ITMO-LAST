CREATE FUNCTION box_le(box, box)
  RETURNS boolean
AS $$
box_le
$$;

