CREATE FUNCTION bttextnamecmp(text, name)
  RETURNS integer
AS $$
bttextnamecmp
$$;

