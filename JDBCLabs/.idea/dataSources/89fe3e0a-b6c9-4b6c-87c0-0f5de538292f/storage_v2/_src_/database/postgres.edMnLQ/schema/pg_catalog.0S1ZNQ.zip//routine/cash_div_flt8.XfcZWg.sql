CREATE FUNCTION cash_div_flt8(money, double precision)
  RETURNS money
AS $$
cash_div_flt8
$$;

