CREATE FUNCTION byteale(bytea, bytea)
  RETURNS boolean
AS $$
byteale
$$;

