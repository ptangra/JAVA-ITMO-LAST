CREATE FUNCTION cidr_out(cidr)
  RETURNS cstring
AS $$
cidr_out
$$;

