CREATE FUNCTION abbrev(cidr)
  RETURNS text
AS $$
cidr_abbrev
$$;

