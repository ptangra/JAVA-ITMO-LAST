CREATE FUNCTION btint4sortsupport(internal)
  RETURNS void
AS $$
btint4sortsupport
$$;

