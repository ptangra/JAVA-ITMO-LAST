CREATE FUNCTION box_above(box, box)
  RETURNS boolean
AS $$
box_above
$$;

