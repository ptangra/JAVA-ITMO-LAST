CREATE FUNCTION array_unnest_support(internal)
  RETURNS internal
AS $$
array_unnest_support
$$;

