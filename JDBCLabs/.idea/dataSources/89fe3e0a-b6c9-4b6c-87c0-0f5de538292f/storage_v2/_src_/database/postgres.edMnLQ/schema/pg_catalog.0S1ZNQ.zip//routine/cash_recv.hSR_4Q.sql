CREATE FUNCTION cash_recv(internal)
  RETURNS money
AS $$
cash_recv
$$;

