CREATE FUNCTION charle("char", "char")
  RETURNS boolean
AS $$
charle
$$;

