CREATE FUNCTION array_positions(anyarray, anyelement)
  RETURNS integer[]
AS $$
array_positions
$$;

