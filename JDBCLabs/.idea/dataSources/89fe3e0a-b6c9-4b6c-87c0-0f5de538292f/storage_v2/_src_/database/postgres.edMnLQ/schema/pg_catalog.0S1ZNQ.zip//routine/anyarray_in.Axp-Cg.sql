CREATE FUNCTION anyarray_in(cstring)
  RETURNS anyarray
AS $$
anyarray_in
$$;

