CREATE FUNCTION charin(cstring)
  RETURNS "char"
AS $$
charin
$$;

