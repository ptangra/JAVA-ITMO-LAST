CREATE FUNCTION bttext_pattern_sortsupport(internal)
  RETURNS void
AS $$
bttext_pattern_sortsupport
$$;

