CREATE FUNCTION array_gt(anyarray, anyarray)
  RETURNS boolean
AS $$
array_gt
$$;

