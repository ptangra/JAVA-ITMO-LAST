CREATE FUNCTION btoidcmp(oid, oid)
  RETURNS integer
AS $$
btoidcmp
$$;

