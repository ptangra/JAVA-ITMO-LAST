CREATE FUNCTION circle_lt(circle, circle)
  RETURNS boolean
AS $$
circle_lt
$$;

