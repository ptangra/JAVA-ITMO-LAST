CREATE FUNCTION bit(integer, integer)
  RETURNS bit
AS $$
bitfromint4
$$;

