CREATE FUNCTION boolout(boolean)
  RETURNS cstring
AS $$
boolout
$$;

