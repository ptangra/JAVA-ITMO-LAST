CREATE FUNCTION aclitemin(cstring)
  RETURNS aclitem
AS $$
aclitemin
$$;

