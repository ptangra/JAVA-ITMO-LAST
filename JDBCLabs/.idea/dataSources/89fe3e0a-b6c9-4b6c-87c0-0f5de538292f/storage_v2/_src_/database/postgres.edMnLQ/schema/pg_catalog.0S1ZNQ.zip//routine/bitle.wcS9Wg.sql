CREATE FUNCTION bitle(bit, bit)
  RETURNS boolean
AS $$
bitle
$$;

