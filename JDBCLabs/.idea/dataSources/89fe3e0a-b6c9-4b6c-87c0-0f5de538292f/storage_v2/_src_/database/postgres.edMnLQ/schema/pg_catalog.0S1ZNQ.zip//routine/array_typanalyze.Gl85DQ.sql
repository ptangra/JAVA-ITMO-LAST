CREATE FUNCTION array_typanalyze(internal)
  RETURNS boolean
AS $$
array_typanalyze
$$;

