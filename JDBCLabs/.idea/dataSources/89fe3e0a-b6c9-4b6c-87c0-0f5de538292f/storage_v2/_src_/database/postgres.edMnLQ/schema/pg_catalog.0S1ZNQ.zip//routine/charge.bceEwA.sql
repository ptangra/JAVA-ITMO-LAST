CREATE FUNCTION charge("char", "char")
  RETURNS boolean
AS $$
charge
$$;

