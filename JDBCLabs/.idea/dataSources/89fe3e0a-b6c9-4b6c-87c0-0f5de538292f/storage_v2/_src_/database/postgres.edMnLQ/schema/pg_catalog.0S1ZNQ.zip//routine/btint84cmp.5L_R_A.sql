CREATE FUNCTION btint84cmp(bigint, integer)
  RETURNS integer
AS $$
btint84cmp
$$;

