CREATE FUNCTION anyelement_out(anyelement)
  RETURNS cstring
AS $$
anyelement_out
$$;

