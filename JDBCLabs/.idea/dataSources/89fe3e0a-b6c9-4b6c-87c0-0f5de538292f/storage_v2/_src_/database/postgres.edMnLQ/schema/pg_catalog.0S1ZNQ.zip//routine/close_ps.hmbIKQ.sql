CREATE FUNCTION close_ps(point, lseg)
  RETURNS point
AS $$
close_ps
$$;

