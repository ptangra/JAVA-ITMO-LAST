CREATE FUNCTION boolor_statefunc(boolean, boolean)
  RETURNS boolean
AS $$
boolor_statefunc
$$;

