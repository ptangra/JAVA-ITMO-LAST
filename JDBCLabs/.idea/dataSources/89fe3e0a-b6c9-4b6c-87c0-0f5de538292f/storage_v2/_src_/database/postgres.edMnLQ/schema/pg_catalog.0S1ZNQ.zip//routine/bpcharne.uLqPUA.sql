CREATE FUNCTION bpcharne(character, character)
  RETURNS boolean
AS $$
bpcharne
$$;

