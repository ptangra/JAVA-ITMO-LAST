CREATE FUNCTION circle_distance(circle, circle)
  RETURNS double precision
AS $$
circle_distance
$$;

