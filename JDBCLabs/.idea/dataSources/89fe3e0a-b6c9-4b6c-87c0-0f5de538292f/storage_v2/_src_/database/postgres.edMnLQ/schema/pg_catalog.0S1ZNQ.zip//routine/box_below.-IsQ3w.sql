CREATE FUNCTION box_below(box, box)
  RETURNS boolean
AS $$
box_below
$$;

