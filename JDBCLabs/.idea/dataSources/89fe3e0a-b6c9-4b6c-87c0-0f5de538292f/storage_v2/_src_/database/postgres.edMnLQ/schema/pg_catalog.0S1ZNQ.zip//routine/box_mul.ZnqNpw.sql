CREATE FUNCTION box_mul(box, point)
  RETURNS box
AS $$
box_mul
$$;

