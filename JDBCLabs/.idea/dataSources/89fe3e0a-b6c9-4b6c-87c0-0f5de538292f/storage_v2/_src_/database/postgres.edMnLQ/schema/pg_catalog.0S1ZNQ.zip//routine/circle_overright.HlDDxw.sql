CREATE FUNCTION circle_overright(circle, circle)
  RETURNS boolean
AS $$
circle_overright
$$;

