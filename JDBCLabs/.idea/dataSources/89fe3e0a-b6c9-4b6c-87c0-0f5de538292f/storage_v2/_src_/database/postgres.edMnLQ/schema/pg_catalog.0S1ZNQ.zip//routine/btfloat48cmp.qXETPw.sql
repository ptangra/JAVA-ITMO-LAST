CREATE FUNCTION btfloat48cmp(real, double precision)
  RETURNS integer
AS $$
btfloat48cmp
$$;

