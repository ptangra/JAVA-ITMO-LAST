CREATE FUNCTION array_larger(anyarray, anyarray)
  RETURNS anyarray
AS $$
array_larger
$$;

