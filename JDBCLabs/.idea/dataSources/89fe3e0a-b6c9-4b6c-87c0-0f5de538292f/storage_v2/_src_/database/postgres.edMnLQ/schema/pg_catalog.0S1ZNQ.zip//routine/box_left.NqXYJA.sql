CREATE FUNCTION box_left(box, box)
  RETURNS boolean
AS $$
box_left
$$;

