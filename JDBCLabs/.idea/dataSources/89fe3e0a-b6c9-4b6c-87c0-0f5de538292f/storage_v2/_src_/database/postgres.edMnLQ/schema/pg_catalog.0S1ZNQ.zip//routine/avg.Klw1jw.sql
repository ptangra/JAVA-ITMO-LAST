CREATE FUNCTION avg(bigint)
  RETURNS numeric
AS $$
aggregate_dummy
$$;

