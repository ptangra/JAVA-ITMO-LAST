CREATE FUNCTION arraycontained(anyarray, anyarray)
  RETURNS boolean
AS $$
arraycontained
$$;

