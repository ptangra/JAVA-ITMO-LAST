CREATE FUNCTION boolin(cstring)
  RETURNS boolean
AS $$
boolin
$$;

