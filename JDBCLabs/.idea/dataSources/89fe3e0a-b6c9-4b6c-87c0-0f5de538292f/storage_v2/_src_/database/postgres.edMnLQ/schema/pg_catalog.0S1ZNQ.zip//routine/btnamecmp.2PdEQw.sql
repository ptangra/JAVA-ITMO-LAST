CREATE FUNCTION btnamecmp(name, name)
  RETURNS integer
AS $$
btnamecmp
$$;

