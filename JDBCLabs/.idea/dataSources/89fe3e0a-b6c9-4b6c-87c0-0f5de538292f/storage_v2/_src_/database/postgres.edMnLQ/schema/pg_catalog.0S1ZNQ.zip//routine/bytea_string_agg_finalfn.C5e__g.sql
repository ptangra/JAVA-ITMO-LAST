CREATE FUNCTION bytea_string_agg_finalfn(internal)
  RETURNS bytea
AS $$
bytea_string_agg_finalfn
$$;

