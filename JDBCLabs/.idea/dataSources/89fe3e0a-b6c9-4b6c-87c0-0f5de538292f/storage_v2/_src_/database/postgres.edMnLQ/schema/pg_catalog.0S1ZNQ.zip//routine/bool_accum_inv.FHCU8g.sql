CREATE FUNCTION bool_accum_inv(internal, boolean)
  RETURNS internal
AS $$
bool_accum_inv
$$;

