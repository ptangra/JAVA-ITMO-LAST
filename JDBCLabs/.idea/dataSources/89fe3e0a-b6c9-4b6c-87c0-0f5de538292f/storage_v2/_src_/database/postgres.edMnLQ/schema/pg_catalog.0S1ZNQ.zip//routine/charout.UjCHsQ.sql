CREATE FUNCTION charout("char")
  RETURNS cstring
AS $$
charout
$$;

