CREATE FUNCTION close_sb(lseg, box)
  RETURNS point
AS $$
close_sb
$$;

