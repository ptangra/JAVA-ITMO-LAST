CREATE FUNCTION binary_upgrade_set_next_heap_pg_class_oid(oid)
  RETURNS void
AS $$
binary_upgrade_set_next_heap_pg_class_oid
$$;

