CREATE FUNCTION btnametextcmp(name, text)
  RETURNS integer
AS $$
btnametextcmp
$$;

