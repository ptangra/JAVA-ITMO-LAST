CREATE FUNCTION box_distance(box, box)
  RETURNS double precision
AS $$
box_distance
$$;

