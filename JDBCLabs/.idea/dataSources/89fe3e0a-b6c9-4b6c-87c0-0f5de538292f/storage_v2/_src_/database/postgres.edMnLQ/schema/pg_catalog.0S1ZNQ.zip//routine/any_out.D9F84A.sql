CREATE FUNCTION any_out("any")
  RETURNS cstring
AS $$
any_out
$$;

