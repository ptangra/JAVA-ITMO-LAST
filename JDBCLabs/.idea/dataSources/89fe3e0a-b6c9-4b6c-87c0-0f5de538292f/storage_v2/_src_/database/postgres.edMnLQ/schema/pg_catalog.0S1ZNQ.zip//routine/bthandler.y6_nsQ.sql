CREATE FUNCTION bthandler(internal)
  RETURNS index_am_handler
AS $$
bthandler
$$;

