CREATE FUNCTION bitshiftright(bit, integer)
  RETURNS bit
AS $$
bitshiftright
$$;

