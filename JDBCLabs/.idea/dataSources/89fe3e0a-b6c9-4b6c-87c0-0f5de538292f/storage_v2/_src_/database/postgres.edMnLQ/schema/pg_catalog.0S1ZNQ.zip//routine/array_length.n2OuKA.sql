CREATE FUNCTION array_length(anyarray, integer)
  RETURNS integer
AS $$
array_length
$$;

