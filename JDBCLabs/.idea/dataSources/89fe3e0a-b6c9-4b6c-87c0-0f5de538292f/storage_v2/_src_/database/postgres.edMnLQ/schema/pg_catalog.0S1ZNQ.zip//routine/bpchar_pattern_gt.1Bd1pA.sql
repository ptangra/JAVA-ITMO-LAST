CREATE FUNCTION bpchar_pattern_gt(character, character)
  RETURNS boolean
AS $$
bpchar_pattern_gt
$$;

