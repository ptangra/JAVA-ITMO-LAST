CREATE FUNCTION byteacmp(bytea, bytea)
  RETURNS integer
AS $$
byteacmp
$$;

