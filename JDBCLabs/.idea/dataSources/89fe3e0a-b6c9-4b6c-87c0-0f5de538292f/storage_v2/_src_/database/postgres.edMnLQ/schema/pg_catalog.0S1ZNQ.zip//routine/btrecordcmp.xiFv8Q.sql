CREATE FUNCTION btrecordcmp(record, record)
  RETURNS integer
AS $$
btrecordcmp
$$;

