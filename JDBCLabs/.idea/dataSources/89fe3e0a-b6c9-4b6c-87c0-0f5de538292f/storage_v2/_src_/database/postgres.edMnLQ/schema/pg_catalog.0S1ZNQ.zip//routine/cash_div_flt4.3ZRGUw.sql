CREATE FUNCTION cash_div_flt4(money, real)
  RETURNS money
AS $$
cash_div_flt4
$$;

