CREATE FUNCTION close_pl(point, line)
  RETURNS point
AS $$
close_pl
$$;

