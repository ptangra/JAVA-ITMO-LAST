CREATE FUNCTION aclremove(aclitem[], aclitem)
  RETURNS aclitem[]
AS $$
aclremove
$$;

