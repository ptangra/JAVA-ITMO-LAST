CREATE FUNCTION bpcharlike(character, text)
  RETURNS boolean
AS $$
textlike
$$;

