CREATE FUNCTION brin_minmax_opcinfo(internal)
  RETURNS internal
AS $$
brin_minmax_opcinfo
$$;

