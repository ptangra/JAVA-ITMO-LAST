CREATE FUNCTION bool_or(boolean)
  RETURNS boolean
AS $$
aggregate_dummy
$$;

