CREATE FUNCTION "RI_FKey_setnull_upd"()
  RETURNS trigger
AS $$
RI_FKey_setnull_upd
$$;

