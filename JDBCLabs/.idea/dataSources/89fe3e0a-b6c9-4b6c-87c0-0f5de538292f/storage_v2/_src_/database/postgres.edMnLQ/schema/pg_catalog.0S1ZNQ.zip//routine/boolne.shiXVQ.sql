CREATE FUNCTION boolne(boolean, boolean)
  RETURNS boolean
AS $$
boolne
$$;

