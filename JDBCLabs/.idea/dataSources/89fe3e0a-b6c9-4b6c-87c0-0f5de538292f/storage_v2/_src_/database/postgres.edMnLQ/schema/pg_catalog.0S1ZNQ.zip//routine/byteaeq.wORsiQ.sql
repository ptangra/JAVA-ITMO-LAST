CREATE FUNCTION byteaeq(bytea, bytea)
  RETURNS boolean
AS $$
byteaeq
$$;

