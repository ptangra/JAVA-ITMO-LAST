CREATE FUNCTION cash_ge(money, money)
  RETURNS boolean
AS $$
cash_ge
$$;

