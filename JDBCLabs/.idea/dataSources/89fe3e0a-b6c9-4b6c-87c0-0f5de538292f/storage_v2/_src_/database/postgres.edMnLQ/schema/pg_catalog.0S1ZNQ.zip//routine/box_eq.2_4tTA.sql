CREATE FUNCTION box_eq(box, box)
  RETURNS boolean
AS $$
box_eq
$$;

