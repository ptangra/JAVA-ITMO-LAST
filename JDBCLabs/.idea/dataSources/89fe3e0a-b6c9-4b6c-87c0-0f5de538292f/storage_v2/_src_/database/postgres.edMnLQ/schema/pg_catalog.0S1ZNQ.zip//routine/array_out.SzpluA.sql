CREATE FUNCTION array_out(anyarray)
  RETURNS cstring
AS $$
array_out
$$;

