CREATE FUNCTION circle_center(circle)
  RETURNS point
AS $$
circle_center
$$;

