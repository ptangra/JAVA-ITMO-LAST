CREATE FUNCTION contjoinsel(internal, oid, internal, smallint, internal)
  RETURNS double precision
AS $$
contjoinsel
$$;

