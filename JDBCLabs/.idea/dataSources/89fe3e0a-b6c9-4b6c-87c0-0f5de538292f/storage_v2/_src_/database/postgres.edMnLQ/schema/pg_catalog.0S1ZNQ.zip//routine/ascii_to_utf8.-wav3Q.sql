CREATE FUNCTION ascii_to_utf8(integer, integer, cstring, internal, integer)
  RETURNS void
AS $$
ascii_to_utf8
$$;

