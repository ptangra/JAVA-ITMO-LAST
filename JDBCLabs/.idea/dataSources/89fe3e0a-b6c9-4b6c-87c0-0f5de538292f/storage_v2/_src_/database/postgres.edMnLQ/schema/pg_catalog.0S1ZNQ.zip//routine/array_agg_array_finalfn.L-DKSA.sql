CREATE FUNCTION array_agg_array_finalfn(internal, anyarray)
  RETURNS anyarray
AS $$
array_agg_array_finalfn
$$;

