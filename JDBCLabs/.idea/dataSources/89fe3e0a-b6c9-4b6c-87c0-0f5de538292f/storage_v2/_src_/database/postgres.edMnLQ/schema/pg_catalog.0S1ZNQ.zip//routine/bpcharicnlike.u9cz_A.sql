CREATE FUNCTION bpcharicnlike(character, text)
  RETURNS boolean
AS $$
texticnlike
$$;

