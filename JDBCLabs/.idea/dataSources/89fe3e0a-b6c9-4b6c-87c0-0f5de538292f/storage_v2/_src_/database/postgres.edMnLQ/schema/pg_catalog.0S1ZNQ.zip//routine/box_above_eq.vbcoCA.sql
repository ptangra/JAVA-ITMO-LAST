CREATE FUNCTION box_above_eq(box, box)
  RETURNS boolean
AS $$
box_above_eq
$$;

