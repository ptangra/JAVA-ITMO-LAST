CREATE FUNCTION cardinality(anyarray)
  RETURNS integer
AS $$
array_cardinality
$$;

