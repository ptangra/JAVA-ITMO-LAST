CREATE FUNCTION array_agg_transfn(internal, anynonarray)
  RETURNS internal
AS $$
array_agg_transfn
$$;

