CREATE FUNCTION box_in(cstring)
  RETURNS box
AS $$
box_in
$$;

