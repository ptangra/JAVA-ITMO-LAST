CREATE FUNCTION bpcharsend(character)
  RETURNS bytea
AS $$
bpcharsend
$$;

