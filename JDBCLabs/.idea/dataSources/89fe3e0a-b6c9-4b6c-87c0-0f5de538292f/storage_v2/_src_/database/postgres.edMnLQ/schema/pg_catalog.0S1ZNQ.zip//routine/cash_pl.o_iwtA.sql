CREATE FUNCTION cash_pl(money, money)
  RETURNS money
AS $$
cash_pl
$$;

