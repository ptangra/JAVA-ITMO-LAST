CREATE FUNCTION bytea_string_agg_transfn(internal, bytea, bytea)
  RETURNS internal
AS $$
bytea_string_agg_transfn
$$;

