CREATE FUNCTION circle_eq(circle, circle)
  RETURNS boolean
AS $$
circle_eq
$$;

