CREATE FUNCTION array_lt(anyarray, anyarray)
  RETURNS boolean
AS $$
array_lt
$$;

