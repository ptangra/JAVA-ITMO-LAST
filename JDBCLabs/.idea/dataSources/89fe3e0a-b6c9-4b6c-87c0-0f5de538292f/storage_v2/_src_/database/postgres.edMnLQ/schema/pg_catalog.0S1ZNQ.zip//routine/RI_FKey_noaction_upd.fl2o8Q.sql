CREATE FUNCTION "RI_FKey_noaction_upd"()
  RETURNS trigger
AS $$
RI_FKey_noaction_upd
$$;

