CREATE FUNCTION circle_below(circle, circle)
  RETURNS boolean
AS $$
circle_below
$$;

