CREATE FUNCTION aclitemeq(aclitem, aclitem)
  RETURNS boolean
AS $$
aclitem_eq
$$;

