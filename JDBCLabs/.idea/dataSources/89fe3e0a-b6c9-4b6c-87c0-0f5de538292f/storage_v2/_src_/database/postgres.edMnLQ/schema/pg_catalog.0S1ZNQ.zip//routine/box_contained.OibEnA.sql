CREATE FUNCTION box_contained(box, box)
  RETURNS boolean
AS $$
box_contained
$$;

