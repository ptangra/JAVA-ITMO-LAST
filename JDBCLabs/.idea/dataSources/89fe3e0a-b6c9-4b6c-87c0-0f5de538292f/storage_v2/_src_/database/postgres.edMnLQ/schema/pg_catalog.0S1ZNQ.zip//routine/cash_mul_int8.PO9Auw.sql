CREATE FUNCTION cash_mul_int8(money, bigint)
  RETURNS money
AS $$
cash_mul_int8
$$;

