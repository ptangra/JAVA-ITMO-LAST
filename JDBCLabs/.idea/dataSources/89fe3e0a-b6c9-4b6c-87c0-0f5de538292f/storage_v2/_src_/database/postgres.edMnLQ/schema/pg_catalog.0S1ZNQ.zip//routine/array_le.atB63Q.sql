CREATE FUNCTION array_le(anyarray, anyarray)
  RETURNS boolean
AS $$
array_le
$$;

