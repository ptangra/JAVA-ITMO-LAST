CREATE FUNCTION anynonarray_out(anynonarray)
  RETURNS cstring
AS $$
anynonarray_out
$$;

