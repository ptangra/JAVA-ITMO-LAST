CREATE FUNCTION concat_ws(text, VARIADIC "any")
  RETURNS text
AS $$
text_concat_ws
$$;

