CREATE FUNCTION byteagt(bytea, bytea)
  RETURNS boolean
AS $$
byteagt
$$;

