CREATE FUNCTION circle_in(cstring)
  RETURNS circle
AS $$
circle_in
$$;

