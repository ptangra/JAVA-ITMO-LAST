CREATE FUNCTION bpchar_larger(character, character)
  RETURNS character
AS $$
bpchar_larger
$$;

