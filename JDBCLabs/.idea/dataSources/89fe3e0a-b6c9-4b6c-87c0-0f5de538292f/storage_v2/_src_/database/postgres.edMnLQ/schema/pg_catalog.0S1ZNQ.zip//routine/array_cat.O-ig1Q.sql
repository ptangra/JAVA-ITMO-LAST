CREATE FUNCTION array_cat(anyarray, anyarray)
  RETURNS anyarray
AS $$
array_cat
$$;

