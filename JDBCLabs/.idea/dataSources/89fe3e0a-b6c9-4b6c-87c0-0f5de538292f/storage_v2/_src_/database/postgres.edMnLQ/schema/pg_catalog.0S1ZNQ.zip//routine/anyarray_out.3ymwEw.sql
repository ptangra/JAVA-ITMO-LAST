CREATE FUNCTION anyarray_out(anyarray)
  RETURNS cstring
AS $$
anyarray_out
$$;

