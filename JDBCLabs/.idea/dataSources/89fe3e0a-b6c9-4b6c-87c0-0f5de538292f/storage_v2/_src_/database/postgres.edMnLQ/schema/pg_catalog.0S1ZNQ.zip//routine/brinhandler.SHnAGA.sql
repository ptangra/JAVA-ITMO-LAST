CREATE FUNCTION brinhandler(internal)
  RETURNS index_am_handler
AS $$
brinhandler
$$;

