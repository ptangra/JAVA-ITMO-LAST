CREATE FUNCTION bool(integer)
  RETURNS boolean
AS $$
int4_bool
$$;

