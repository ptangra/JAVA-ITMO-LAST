CREATE FUNCTION "RI_FKey_setdefault_upd"()
  RETURNS trigger
AS $$
RI_FKey_setdefault_upd
$$;

