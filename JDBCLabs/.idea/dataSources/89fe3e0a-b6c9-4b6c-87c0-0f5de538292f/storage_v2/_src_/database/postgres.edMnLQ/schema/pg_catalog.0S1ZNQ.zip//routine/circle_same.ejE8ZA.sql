CREATE FUNCTION circle_same(circle, circle)
  RETURNS boolean
AS $$
circle_same
$$;

