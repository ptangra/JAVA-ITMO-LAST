CREATE FUNCTION bpcharin(cstring, oid, integer)
  RETURNS character
AS $$
bpcharin
$$;

