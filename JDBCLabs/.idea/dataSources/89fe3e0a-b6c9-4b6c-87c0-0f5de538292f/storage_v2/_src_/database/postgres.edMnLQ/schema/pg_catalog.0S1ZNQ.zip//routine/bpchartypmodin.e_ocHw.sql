CREATE FUNCTION bpchartypmodin(cstring[])
  RETURNS integer
AS $$
bpchartypmodin
$$;

