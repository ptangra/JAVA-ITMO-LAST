CREATE FUNCTION booleq(boolean, boolean)
  RETURNS boolean
AS $$
booleq
$$;

