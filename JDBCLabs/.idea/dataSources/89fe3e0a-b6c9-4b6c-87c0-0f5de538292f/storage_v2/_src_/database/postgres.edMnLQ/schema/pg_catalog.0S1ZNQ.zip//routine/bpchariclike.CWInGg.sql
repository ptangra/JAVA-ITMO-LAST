CREATE FUNCTION bpchariclike(character, text)
  RETURNS boolean
AS $$
texticlike
$$;

