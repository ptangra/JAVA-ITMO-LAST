CREATE FUNCTION binary_upgrade_set_next_array_pg_type_oid(oid)
  RETURNS void
AS $$
binary_upgrade_set_next_array_pg_type_oid
$$;

