CREATE FUNCTION brin_minmax_union(internal, internal, internal)
  RETURNS boolean
AS $$
brin_minmax_union
$$;

