CREATE FUNCTION binary_upgrade_set_next_pg_authid_oid(oid)
  RETURNS void
AS $$
binary_upgrade_set_next_pg_authid_oid
$$;

