CREATE FUNCTION circle_ge(circle, circle)
  RETURNS boolean
AS $$
circle_ge
$$;

