CREATE FUNCTION btint24cmp(smallint, integer)
  RETURNS integer
AS $$
btint24cmp
$$;

