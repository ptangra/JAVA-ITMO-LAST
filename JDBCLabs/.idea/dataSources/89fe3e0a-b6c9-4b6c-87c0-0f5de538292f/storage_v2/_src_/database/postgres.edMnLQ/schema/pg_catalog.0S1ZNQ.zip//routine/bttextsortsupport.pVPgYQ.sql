CREATE FUNCTION bttextsortsupport(internal)
  RETURNS void
AS $$
bttextsortsupport
$$;

