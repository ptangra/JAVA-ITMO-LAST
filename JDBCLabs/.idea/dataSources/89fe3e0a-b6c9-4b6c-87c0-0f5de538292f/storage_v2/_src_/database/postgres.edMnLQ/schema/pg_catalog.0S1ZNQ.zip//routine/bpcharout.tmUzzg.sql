CREATE FUNCTION bpcharout(character)
  RETURNS cstring
AS $$
bpcharout
$$;

