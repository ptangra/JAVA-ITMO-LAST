CREATE FUNCTION close_lseg(lseg, lseg)
  RETURNS point
AS $$
close_lseg
$$;

