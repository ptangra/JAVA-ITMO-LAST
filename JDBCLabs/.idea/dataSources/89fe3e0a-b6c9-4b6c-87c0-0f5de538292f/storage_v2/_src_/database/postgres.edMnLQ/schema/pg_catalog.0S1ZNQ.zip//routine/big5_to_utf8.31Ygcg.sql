CREATE FUNCTION big5_to_utf8(integer, integer, cstring, internal, integer)
  RETURNS void
AS $$
big5_to_utf8
$$;

