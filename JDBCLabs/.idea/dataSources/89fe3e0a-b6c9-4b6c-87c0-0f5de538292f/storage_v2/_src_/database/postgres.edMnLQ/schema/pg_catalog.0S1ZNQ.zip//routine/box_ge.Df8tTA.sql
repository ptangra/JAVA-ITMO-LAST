CREATE FUNCTION box_ge(box, box)
  RETURNS boolean
AS $$
box_ge
$$;

