CREATE FUNCTION btarraycmp(anyarray, anyarray)
  RETURNS integer
AS $$
btarraycmp
$$;

