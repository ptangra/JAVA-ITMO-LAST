CREATE FUNCTION cash_eq(money, money)
  RETURNS boolean
AS $$
cash_eq
$$;

