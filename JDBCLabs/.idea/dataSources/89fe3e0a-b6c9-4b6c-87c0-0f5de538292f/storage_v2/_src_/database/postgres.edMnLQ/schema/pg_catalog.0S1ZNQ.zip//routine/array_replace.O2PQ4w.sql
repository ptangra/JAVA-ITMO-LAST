CREATE FUNCTION array_replace(anyarray, anyelement, anyelement)
  RETURNS anyarray
AS $$
array_replace
$$;

