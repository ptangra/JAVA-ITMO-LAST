CREATE FUNCTION array_ge(anyarray, anyarray)
  RETURNS boolean
AS $$
array_ge
$$;

