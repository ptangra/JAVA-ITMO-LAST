CREATE FUNCTION anyrange_out(anyrange)
  RETURNS cstring
AS $$
anyrange_out
$$;

