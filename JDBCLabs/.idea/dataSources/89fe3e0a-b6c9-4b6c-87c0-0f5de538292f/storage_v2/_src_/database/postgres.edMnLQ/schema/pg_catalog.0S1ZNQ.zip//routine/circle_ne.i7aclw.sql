CREATE FUNCTION circle_ne(circle, circle)
  RETURNS boolean
AS $$
circle_ne
$$;

