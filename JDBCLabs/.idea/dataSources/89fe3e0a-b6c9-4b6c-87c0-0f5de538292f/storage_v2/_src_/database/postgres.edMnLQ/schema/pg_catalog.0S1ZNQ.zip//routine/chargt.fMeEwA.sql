CREATE FUNCTION chargt("char", "char")
  RETURNS boolean
AS $$
chargt
$$;

