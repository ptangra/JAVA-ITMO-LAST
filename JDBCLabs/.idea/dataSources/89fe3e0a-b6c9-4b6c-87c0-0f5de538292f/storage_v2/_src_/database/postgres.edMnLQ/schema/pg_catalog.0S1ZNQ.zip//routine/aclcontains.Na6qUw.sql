CREATE FUNCTION aclcontains(aclitem[], aclitem)
  RETURNS boolean
AS $$
aclcontains
$$;

