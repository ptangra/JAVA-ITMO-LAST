CREATE FUNCTION boolsend(boolean)
  RETURNS bytea
AS $$
boolsend
$$;

