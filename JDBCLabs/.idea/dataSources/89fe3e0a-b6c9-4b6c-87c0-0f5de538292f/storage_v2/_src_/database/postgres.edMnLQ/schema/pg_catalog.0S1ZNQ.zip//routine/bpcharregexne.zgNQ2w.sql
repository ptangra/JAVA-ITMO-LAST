CREATE FUNCTION bpcharregexne(character, text)
  RETURNS boolean
AS $$
textregexne
$$;

