CREATE FUNCTION area(box)
  RETURNS double precision
AS $$
box_area
$$;

