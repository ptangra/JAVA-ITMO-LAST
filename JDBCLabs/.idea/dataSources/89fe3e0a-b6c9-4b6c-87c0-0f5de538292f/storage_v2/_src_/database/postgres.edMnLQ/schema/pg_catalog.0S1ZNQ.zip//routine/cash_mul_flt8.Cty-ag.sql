CREATE FUNCTION cash_mul_flt8(money, double precision)
  RETURNS money
AS $$
cash_mul_flt8
$$;

