CREATE FUNCTION arraycontjoinsel(internal, oid, internal, smallint, internal)
  RETURNS double precision
AS $$
arraycontjoinsel
$$;

