CREATE FUNCTION bpchar_sortsupport(internal)
  RETURNS void
AS $$
bpchar_sortsupport
$$;

