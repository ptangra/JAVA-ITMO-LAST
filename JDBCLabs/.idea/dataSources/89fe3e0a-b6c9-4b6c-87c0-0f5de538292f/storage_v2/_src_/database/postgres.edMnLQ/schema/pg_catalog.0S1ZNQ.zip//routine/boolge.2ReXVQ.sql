CREATE FUNCTION boolge(boolean, boolean)
  RETURNS boolean
AS $$
boolge
$$;

