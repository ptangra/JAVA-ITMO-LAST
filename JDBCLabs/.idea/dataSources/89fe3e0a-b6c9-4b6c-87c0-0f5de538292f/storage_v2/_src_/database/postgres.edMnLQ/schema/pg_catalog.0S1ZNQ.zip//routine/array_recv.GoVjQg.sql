CREATE FUNCTION array_recv(internal, oid, integer)
  RETURNS anyarray
AS $$
array_recv
$$;

