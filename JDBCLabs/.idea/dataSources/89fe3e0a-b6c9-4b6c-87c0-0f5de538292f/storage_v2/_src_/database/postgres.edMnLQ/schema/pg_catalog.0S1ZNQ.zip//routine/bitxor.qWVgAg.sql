CREATE FUNCTION bitxor(bit, bit)
  RETURNS bit
AS $$
bitxor
$$;

