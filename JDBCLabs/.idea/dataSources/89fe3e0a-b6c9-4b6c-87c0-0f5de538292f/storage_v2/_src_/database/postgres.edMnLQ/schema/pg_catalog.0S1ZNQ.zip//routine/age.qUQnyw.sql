CREATE FUNCTION age(xid)
  RETURNS integer
AS $$
xid_age
$$;

