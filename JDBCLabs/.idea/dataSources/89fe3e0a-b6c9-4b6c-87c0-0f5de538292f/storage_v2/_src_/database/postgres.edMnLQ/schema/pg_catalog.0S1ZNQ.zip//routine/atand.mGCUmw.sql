CREATE FUNCTION atand(double precision)
  RETURNS double precision
AS $$
datand
$$;

