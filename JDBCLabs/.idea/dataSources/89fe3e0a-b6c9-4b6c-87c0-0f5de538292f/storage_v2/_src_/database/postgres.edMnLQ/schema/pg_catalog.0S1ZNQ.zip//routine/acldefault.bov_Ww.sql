CREATE FUNCTION acldefault("char", oid)
  RETURNS aclitem[]
AS $$
acldefault_sql
$$;

