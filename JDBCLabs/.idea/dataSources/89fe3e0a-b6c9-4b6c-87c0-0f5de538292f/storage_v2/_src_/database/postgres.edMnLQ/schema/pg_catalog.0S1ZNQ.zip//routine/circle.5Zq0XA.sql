CREATE FUNCTION circle(point, double precision)
  RETURNS circle
AS $$
cr_circle
$$;

