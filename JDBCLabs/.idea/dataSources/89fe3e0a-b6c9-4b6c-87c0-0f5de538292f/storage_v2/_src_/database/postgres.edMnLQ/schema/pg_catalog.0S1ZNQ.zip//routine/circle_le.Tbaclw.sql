CREATE FUNCTION circle_le(circle, circle)
  RETURNS boolean
AS $$
circle_le
$$;

