CREATE FUNCTION array_prepend(anyelement, anyarray)
  RETURNS anyarray
AS $$
array_prepend
$$;

