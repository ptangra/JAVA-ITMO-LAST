CREATE FUNCTION btbpchar_pattern_cmp(character, character)
  RETURNS integer
AS $$
btbpchar_pattern_cmp
$$;

