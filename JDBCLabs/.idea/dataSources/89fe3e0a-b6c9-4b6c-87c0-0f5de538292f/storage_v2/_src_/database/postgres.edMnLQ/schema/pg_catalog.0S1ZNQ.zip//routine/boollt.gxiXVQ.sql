CREATE FUNCTION boollt(boolean, boolean)
  RETURNS boolean
AS $$
boollt
$$;

