CREATE FUNCTION circle_overlap(circle, circle)
  RETURNS boolean
AS $$
circle_overlap
$$;

