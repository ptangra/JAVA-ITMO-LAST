CREATE FUNCTION concat(VARIADIC "any")
  RETURNS text
AS $$
text_concat
$$;

