CREATE FUNCTION box_send(box)
  RETURNS bytea
AS $$
box_send
$$;

