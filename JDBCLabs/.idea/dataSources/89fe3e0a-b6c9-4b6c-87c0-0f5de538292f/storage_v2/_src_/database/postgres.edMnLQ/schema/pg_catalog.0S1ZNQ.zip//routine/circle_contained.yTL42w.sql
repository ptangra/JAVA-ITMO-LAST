CREATE FUNCTION circle_contained(circle, circle)
  RETURNS boolean
AS $$
circle_contained
$$;

