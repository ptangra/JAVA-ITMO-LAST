CREATE FUNCTION circle_recv(internal)
  RETURNS circle
AS $$
circle_recv
$$;

