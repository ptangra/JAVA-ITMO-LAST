CREATE FUNCTION cash_mul_int2(money, smallint)
  RETURNS money
AS $$
cash_mul_int2
$$;

