CREATE FUNCTION convert(bytea, name, name)
  RETURNS bytea
AS $$
pg_convert
$$;

