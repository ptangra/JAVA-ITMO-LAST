CREATE FUNCTION binary_upgrade_set_next_pg_enum_oid(oid)
  RETURNS void
AS $$
binary_upgrade_set_next_pg_enum_oid
$$;

