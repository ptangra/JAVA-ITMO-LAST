CREATE FUNCTION array_to_tsvector(text[])
  RETURNS tsvector
AS $$
array_to_tsvector
$$;

