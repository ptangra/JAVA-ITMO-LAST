CREATE FUNCTION cash_le(money, money)
  RETURNS boolean
AS $$
cash_le
$$;

