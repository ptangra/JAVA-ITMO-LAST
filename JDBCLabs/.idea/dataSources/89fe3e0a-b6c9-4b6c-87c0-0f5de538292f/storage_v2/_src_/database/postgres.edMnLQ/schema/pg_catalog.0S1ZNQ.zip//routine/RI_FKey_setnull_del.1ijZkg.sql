CREATE FUNCTION "RI_FKey_setnull_del"()
  RETURNS trigger
AS $$
RI_FKey_setnull_del
$$;

