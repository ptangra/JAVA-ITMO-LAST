CREATE FUNCTION bool_accum(internal, boolean)
  RETURNS internal
AS $$
bool_accum
$$;

