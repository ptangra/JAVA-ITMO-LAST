CREATE FUNCTION cash_div_int4(money, integer)
  RETURNS money
AS $$
cash_div_int4
$$;

