CREATE FUNCTION close_sl(lseg, line)
  RETURNS point
AS $$
close_sl
$$;

