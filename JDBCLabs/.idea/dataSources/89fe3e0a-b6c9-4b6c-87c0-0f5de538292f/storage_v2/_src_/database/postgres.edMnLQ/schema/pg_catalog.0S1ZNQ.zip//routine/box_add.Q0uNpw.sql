CREATE FUNCTION box_add(box, point)
  RETURNS box
AS $$
box_add
$$;

