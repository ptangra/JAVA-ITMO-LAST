CREATE FUNCTION contsel(internal, oid, internal, integer)
  RETURNS double precision
AS $$
contsel
$$;

