CREATE FUNCTION arraycontsel(internal, oid, internal, integer)
  RETURNS double precision
AS $$
arraycontsel
$$;

