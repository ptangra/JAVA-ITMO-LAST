CREATE FUNCTION box_lt(box, box)
  RETURNS boolean
AS $$
box_lt
$$;

