CREATE FUNCTION bttidcmp(tid, tid)
  RETURNS integer
AS $$
bttidcmp
$$;

