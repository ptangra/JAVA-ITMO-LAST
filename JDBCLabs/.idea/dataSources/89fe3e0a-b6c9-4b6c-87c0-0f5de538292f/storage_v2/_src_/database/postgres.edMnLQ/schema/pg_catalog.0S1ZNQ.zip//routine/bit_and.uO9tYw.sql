CREATE FUNCTION bit_and(smallint)
  RETURNS smallint
AS $$
aggregate_dummy
$$;

