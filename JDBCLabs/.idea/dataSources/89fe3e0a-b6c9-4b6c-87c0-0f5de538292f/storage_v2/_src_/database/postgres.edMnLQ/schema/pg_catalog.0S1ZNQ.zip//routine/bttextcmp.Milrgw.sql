CREATE FUNCTION bttextcmp(text, text)
  RETURNS integer
AS $$
bttextcmp
$$;

