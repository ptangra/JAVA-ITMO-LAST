CREATE FUNCTION bpcharle(character, character)
  RETURNS boolean
AS $$
bpcharle
$$;

