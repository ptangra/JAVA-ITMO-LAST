CREATE FUNCTION bit_or(smallint)
  RETURNS smallint
AS $$
aggregate_dummy
$$;

