CREATE FUNCTION charrecv(internal)
  RETURNS "char"
AS $$
charrecv
$$;

