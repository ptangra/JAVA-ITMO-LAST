CREATE FUNCTION bpchar(name)
  RETURNS character
AS $$
name_bpchar
$$;

