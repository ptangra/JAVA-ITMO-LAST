CREATE FUNCTION any_in(cstring)
  RETURNS "any"
AS $$
any_in
$$;

