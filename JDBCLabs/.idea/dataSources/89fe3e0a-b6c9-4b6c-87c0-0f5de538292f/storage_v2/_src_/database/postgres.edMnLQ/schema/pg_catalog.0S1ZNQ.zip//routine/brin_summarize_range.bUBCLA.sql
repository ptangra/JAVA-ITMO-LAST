CREATE FUNCTION brin_summarize_range(regclass, bigint)
  RETURNS integer
AS $$
brin_summarize_range
$$;

