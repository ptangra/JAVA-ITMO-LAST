CREATE FUNCTION box_sub(box, point)
  RETURNS box
AS $$
box_sub
$$;

