CREATE FUNCTION circle_out(circle)
  RETURNS cstring
AS $$
circle_out
$$;

