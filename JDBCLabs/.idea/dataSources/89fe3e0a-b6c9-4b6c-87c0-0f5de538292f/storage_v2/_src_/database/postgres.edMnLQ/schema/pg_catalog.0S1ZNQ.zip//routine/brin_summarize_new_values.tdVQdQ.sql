CREATE FUNCTION brin_summarize_new_values(regclass)
  RETURNS integer
AS $$
brin_summarize_new_values
$$;

