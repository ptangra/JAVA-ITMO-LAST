CREATE FUNCTION box(point, point)
  RETURNS box
AS $$
points_box
$$;

