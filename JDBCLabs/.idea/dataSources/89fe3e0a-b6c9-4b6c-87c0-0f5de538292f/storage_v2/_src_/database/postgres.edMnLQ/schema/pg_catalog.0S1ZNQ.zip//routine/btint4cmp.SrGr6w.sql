CREATE FUNCTION btint4cmp(integer, integer)
  RETURNS integer
AS $$
btint4cmp
$$;

