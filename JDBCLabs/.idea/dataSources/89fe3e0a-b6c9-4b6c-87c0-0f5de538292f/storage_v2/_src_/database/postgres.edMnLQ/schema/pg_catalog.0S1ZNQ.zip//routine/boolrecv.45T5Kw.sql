CREATE FUNCTION boolrecv(internal)
  RETURNS boolean
AS $$
boolrecv
$$;

