CREATE FUNCTION circle_send(circle)
  RETURNS bytea
AS $$
circle_send
$$;

