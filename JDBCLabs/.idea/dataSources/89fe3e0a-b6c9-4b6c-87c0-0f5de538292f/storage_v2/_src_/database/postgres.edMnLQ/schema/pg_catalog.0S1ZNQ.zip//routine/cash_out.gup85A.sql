CREATE FUNCTION cash_out(money)
  RETURNS cstring
AS $$
cash_out
$$;

