CREATE FUNCTION atanh(double precision)
  RETURNS double precision
AS $$
datanh
$$;

