CREATE FUNCTION anyrange_in(cstring, oid, integer)
  RETURNS anyrange
AS $$
anyrange_in
$$;

