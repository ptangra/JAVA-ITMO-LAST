CREATE FUNCTION array_ne(anyarray, anyarray)
  RETURNS boolean
AS $$
array_ne
$$;

