CREATE FUNCTION array_agg(anyarray)
  RETURNS anyarray
AS $$
aggregate_dummy
$$;

