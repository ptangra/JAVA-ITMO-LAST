CREATE FUNCTION atan(double precision)
  RETURNS double precision
AS $$
datan
$$;

