CREATE FUNCTION close_lb(line, box)
  RETURNS point
AS $$
close_lb
$$;

