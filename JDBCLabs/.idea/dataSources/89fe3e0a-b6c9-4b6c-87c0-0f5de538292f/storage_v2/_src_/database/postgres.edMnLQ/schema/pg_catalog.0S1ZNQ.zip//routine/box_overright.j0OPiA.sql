CREATE FUNCTION box_overright(box, box)
  RETURNS boolean
AS $$
box_overright
$$;

