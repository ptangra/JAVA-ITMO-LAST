CREATE FUNCTION box_contain(box, box)
  RETURNS boolean
AS $$
box_contain
$$;

