CREATE FUNCTION array_to_string(anyarray, text)
  RETURNS text
AS $$
array_to_text
$$;

