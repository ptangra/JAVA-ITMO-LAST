CREATE FUNCTION btoidsortsupport(internal)
  RETURNS void
AS $$
btoidsortsupport
$$;

