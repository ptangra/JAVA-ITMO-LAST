CREATE FUNCTION "RI_FKey_check_ins"()
  RETURNS trigger
AS $$
RI_FKey_check_ins
$$;

