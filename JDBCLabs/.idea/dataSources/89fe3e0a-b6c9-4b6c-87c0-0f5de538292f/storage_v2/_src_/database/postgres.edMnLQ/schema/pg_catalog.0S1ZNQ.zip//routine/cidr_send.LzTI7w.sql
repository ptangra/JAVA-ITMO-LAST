CREATE FUNCTION cidr_send(cidr)
  RETURNS bytea
AS $$
cidr_send
$$;

