CREATE FUNCTION cash_mul_flt4(money, real)
  RETURNS money
AS $$
cash_mul_flt4
$$;

