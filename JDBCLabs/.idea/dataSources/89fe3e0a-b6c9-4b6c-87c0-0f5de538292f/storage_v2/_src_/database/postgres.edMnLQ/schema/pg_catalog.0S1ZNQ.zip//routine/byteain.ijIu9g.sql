CREATE FUNCTION byteain(cstring)
  RETURNS bytea
AS $$
byteain
$$;

