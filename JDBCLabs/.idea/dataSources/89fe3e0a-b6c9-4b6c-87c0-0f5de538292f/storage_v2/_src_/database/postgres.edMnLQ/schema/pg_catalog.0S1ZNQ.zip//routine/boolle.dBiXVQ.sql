CREATE FUNCTION boolle(boolean, boolean)
  RETURNS boolean
AS $$
boolle
$$;

