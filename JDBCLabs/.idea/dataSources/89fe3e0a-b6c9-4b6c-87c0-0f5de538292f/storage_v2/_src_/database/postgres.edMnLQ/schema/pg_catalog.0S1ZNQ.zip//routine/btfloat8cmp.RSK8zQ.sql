CREATE FUNCTION btfloat8cmp(double precision, double precision)
  RETURNS integer
AS $$
btfloat8cmp
$$;

