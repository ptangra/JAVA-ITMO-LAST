CREATE FUNCTION box_intersect(box, box)
  RETURNS box
AS $$
box_intersect
$$;

