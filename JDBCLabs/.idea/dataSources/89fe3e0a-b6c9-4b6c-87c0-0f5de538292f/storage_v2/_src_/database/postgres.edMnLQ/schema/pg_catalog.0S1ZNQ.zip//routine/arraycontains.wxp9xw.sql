CREATE FUNCTION arraycontains(anyarray, anyarray)
  RETURNS boolean
AS $$
arraycontains
$$;

