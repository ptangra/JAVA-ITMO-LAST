CREATE FUNCTION char_length(text)
  RETURNS integer
AS $$
textlen
$$;

