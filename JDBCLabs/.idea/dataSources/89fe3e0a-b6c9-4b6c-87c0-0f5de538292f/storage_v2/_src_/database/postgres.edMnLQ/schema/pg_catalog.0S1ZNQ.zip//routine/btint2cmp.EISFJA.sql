CREATE FUNCTION btint2cmp(smallint, smallint)
  RETURNS integer
AS $$
btint2cmp
$$;

