CREATE FUNCTION acos(double precision)
  RETURNS double precision
AS $$
dacos
$$;

