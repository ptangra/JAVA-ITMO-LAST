CREATE FUNCTION btint8cmp(bigint, bigint)
  RETURNS integer
AS $$
btint8cmp
$$;

