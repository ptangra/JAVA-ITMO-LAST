CREATE FUNCTION ascii_to_mic(integer, integer, cstring, internal, integer)
  RETURNS void
AS $$
ascii_to_mic
$$;

