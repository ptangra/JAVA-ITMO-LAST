CREATE FUNCTION cash_div_int2(money, smallint)
  RETURNS money
AS $$
cash_div_int2
$$;

