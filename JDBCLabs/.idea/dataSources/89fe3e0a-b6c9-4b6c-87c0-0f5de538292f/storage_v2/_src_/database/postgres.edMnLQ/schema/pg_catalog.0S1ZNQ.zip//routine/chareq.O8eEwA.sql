CREATE FUNCTION chareq("char", "char")
  RETURNS boolean
AS $$
chareq
$$;

