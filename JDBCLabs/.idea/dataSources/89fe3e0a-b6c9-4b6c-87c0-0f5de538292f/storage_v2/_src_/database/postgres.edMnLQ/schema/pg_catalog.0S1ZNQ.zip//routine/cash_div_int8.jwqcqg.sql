CREATE FUNCTION cash_div_int8(money, bigint)
  RETURNS money
AS $$
cash_div_int8
$$;

