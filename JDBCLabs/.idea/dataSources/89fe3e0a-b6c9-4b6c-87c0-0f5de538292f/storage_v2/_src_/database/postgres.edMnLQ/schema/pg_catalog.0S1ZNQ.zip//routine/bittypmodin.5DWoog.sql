CREATE FUNCTION bittypmodin(cstring[])
  RETURNS integer
AS $$
bittypmodin
$$;

