CREATE FUNCTION ascii(text)
  RETURNS integer
AS $$
ascii
$$;

