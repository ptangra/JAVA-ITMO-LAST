CREATE FUNCTION bpcharicregexeq(character, text)
  RETURNS boolean
AS $$
texticregexeq
$$;

