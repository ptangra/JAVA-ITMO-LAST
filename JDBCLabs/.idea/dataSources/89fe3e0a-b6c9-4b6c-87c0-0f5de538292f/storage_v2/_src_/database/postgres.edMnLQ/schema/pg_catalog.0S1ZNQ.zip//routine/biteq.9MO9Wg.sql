CREATE FUNCTION biteq(bit, bit)
  RETURNS boolean
AS $$
biteq
$$;

