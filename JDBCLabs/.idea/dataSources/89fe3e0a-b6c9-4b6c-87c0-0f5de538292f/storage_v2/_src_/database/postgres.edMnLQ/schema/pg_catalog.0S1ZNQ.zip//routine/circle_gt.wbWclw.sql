CREATE FUNCTION circle_gt(circle, circle)
  RETURNS boolean
AS $$
circle_gt
$$;

