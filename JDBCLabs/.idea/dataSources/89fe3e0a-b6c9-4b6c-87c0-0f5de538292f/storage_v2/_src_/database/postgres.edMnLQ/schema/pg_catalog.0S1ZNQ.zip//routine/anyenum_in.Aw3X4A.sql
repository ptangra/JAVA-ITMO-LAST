CREATE FUNCTION anyenum_in(cstring)
  RETURNS anyenum
AS $$
anyenum_in
$$;

