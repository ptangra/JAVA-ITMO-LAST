CREATE FUNCTION amvalidate(oid)
  RETURNS boolean
AS $$
amvalidate
$$;

