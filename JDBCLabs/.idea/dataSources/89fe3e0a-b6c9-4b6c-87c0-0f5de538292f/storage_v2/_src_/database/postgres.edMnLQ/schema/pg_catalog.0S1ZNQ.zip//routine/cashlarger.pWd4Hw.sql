CREATE FUNCTION cashlarger(money, money)
  RETURNS money
AS $$
cashlarger
$$;

