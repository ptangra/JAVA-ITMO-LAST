CREATE FUNCTION box_recv(internal)
  RETURNS box
AS $$
box_recv
$$;

