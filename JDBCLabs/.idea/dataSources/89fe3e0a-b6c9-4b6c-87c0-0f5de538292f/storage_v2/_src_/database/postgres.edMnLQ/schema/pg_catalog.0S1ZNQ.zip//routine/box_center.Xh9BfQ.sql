CREATE FUNCTION box_center(box)
  RETURNS point
AS $$
box_center
$$;

