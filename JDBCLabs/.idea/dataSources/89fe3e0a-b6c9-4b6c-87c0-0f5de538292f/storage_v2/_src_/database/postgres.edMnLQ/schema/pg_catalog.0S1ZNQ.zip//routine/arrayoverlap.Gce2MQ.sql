CREATE FUNCTION arrayoverlap(anyarray, anyarray)
  RETURNS boolean
AS $$
arrayoverlap
$$;

