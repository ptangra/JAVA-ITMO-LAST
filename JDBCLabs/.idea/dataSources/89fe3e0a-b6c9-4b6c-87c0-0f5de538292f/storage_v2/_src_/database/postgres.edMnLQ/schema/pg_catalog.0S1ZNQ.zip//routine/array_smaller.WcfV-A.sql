CREATE FUNCTION array_smaller(anyarray, anyarray)
  RETURNS anyarray
AS $$
array_smaller
$$;

