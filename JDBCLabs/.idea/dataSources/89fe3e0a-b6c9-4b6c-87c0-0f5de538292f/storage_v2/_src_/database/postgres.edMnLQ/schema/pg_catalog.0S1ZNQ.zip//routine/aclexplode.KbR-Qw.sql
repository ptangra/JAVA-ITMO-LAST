CREATE FUNCTION aclexplode(acl aclitem[], OUT grantor oid, OUT grantee oid, OUT privilege_type text, OUT is_grantable boolean)
  RETURNS SETOF record
AS $$
aclexplode
$$;

