CREATE FUNCTION bound_box(box, box)
  RETURNS box
AS $$
boxes_bound_box
$$;

