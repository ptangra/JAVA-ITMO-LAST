CREATE FUNCTION btcharcmp("char", "char")
  RETURNS integer
AS $$
btcharcmp
$$;

