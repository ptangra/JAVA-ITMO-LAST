CREATE FUNCTION box_contain_pt(box, point)
  RETURNS boolean
AS $$
box_contain_pt
$$;

