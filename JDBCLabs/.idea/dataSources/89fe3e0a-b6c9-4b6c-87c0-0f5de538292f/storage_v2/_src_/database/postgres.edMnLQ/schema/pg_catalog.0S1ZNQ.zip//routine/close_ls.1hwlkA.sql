CREATE FUNCTION close_ls(line, lseg)
  RETURNS point
AS $$
close_ls
$$;

