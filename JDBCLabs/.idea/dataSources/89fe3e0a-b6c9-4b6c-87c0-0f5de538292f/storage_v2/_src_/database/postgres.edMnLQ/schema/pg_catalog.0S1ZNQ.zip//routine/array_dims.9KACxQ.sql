CREATE FUNCTION array_dims(anyarray)
  RETURNS text
AS $$
array_dims
$$;

