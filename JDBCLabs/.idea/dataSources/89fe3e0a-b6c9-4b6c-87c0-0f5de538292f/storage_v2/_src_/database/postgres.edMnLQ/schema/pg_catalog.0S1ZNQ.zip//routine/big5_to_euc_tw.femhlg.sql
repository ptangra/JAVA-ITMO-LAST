CREATE FUNCTION big5_to_euc_tw(integer, integer, cstring, internal, integer)
  RETURNS void
AS $$
big5_to_euc_tw
$$;

