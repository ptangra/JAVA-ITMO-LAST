CREATE FUNCTION cbrt(double precision)
  RETURNS double precision
AS $$
dcbrt
$$;

