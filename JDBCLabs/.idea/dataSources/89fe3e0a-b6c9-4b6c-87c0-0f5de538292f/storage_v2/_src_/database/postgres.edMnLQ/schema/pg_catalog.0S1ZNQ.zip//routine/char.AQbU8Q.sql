CREATE FUNCTION char(integer)
  RETURNS "char"
AS $$
i4tochar
$$;

