CREATE FUNCTION bitcat(bit varying, bit varying)
  RETURNS bit varying
AS $$
bitcat
$$;

