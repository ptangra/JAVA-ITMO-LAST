CREATE FUNCTION box_overleft(box, box)
  RETURNS boolean
AS $$
box_overleft
$$;

