CREATE FUNCTION close_pb(point, box)
  RETURNS point
AS $$
close_pb
$$;

