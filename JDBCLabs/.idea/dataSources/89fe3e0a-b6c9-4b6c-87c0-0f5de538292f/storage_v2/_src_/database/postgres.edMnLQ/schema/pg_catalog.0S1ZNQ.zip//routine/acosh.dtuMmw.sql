CREATE FUNCTION acosh(double precision)
  RETURNS double precision
AS $$
dacosh
$$;

