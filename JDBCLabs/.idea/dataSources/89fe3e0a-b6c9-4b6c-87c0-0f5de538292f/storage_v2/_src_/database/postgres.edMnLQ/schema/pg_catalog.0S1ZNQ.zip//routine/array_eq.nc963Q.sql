CREATE FUNCTION array_eq(anyarray, anyarray)
  RETURNS boolean
AS $$
array_eq
$$;

