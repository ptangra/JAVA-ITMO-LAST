CREATE FUNCTION btint28cmp(smallint, bigint)
  RETURNS integer
AS $$
btint28cmp
$$;

