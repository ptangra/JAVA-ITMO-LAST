CREATE FUNCTION brin_inclusion_union(internal, internal, internal)
  RETURNS boolean
AS $$
brin_inclusion_union
$$;

