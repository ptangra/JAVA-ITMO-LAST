CREATE FUNCTION box_same(box, box)
  RETURNS boolean
AS $$
box_same
$$;

