CREATE FUNCTION brin_minmax_consistent(internal, internal, internal)
  RETURNS boolean
AS $$
brin_minmax_consistent
$$;

