CREATE FUNCTION bytea_sortsupport(internal)
  RETURNS void
AS $$
bytea_sortsupport
$$;

