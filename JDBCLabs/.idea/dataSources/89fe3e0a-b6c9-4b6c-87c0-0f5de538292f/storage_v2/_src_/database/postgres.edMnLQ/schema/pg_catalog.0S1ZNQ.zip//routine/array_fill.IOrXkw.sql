CREATE FUNCTION array_fill(anyelement, integer[])
  RETURNS anyarray
AS $$
array_fill
$$;

