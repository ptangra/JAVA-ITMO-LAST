CREATE FUNCTION btoidvectorcmp(oidvector, oidvector)
  RETURNS integer
AS $$
btoidvectorcmp
$$;

