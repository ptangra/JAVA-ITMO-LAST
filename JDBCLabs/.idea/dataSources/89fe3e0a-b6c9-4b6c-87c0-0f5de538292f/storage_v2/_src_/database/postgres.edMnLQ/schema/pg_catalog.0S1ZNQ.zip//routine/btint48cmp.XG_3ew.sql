CREATE FUNCTION btint48cmp(integer, bigint)
  RETURNS integer
AS $$
btint48cmp
$$;

