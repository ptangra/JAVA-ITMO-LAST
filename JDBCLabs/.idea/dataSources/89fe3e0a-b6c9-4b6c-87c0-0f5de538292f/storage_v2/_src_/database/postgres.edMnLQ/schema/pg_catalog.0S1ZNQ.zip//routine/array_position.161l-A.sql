CREATE FUNCTION array_position(anyarray, anyelement)
  RETURNS integer
AS $$
array_position
$$;

