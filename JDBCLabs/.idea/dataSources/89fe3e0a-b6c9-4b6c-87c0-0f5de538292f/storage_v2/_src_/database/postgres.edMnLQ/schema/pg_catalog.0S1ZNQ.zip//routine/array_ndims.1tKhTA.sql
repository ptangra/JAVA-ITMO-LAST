CREATE FUNCTION array_ndims(anyarray)
  RETURNS integer
AS $$
array_ndims
$$;

