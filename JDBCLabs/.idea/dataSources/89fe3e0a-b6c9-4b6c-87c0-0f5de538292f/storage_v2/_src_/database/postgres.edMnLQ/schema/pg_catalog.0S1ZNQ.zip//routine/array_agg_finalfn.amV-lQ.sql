CREATE FUNCTION array_agg_finalfn(internal, anynonarray)
  RETURNS anyarray
AS $$
array_agg_finalfn
$$;

