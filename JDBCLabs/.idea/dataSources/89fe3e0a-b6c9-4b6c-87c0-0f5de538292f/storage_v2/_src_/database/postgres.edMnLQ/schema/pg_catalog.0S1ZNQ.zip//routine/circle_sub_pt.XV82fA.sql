CREATE FUNCTION circle_sub_pt(circle, point)
  RETURNS circle
AS $$
circle_sub_pt
$$;

