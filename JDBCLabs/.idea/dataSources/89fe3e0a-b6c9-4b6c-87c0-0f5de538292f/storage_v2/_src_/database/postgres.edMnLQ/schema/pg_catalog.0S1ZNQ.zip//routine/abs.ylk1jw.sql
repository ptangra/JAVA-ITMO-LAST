CREATE FUNCTION abs(real)
  RETURNS real
AS $$
float4abs
$$;

