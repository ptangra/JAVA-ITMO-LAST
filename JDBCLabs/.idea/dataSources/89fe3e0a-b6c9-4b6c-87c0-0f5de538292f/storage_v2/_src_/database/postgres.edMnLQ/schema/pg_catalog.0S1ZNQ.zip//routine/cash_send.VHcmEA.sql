CREATE FUNCTION cash_send(money)
  RETURNS bytea
AS $$
cash_send
$$;

