CREATE FUNCTION bytealt(bytea, bytea)
  RETURNS boolean
AS $$
bytealt
$$;

