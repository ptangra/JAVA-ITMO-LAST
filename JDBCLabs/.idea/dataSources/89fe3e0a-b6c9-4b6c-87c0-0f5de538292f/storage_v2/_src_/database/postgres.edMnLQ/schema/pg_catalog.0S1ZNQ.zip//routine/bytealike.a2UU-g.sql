CREATE FUNCTION bytealike(bytea, bytea)
  RETURNS boolean
AS $$
bytealike
$$;

