CREATE FUNCTION btfloat4cmp(real, real)
  RETURNS integer
AS $$
btfloat4cmp
$$;

