CREATE FUNCTION box_overlap(box, box)
  RETURNS boolean
AS $$
box_overlap
$$;

