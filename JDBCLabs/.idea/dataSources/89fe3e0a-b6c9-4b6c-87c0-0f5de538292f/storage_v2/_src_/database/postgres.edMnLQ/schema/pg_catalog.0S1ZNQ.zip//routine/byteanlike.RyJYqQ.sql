CREATE FUNCTION byteanlike(bytea, bytea)
  RETURNS boolean
AS $$
byteanlike
$$;

