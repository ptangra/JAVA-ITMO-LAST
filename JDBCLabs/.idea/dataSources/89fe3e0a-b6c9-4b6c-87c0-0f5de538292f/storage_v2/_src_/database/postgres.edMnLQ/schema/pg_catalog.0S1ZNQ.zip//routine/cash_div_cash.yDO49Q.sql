CREATE FUNCTION cash_div_cash(money, money)
  RETURNS double precision
AS $$
cash_div_cash
$$;

