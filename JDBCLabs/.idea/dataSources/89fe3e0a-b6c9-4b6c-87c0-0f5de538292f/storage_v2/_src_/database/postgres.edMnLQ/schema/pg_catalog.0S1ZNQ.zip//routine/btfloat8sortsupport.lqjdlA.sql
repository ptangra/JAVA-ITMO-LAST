CREATE FUNCTION btfloat8sortsupport(internal)
  RETURNS void
AS $$
btfloat8sortsupport
$$;

