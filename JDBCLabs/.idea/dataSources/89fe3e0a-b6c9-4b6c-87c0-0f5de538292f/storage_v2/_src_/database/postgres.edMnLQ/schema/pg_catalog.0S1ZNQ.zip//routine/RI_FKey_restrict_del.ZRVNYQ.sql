CREATE FUNCTION "RI_FKey_restrict_del"()
  RETURNS trigger
AS $$
RI_FKey_restrict_del
$$;

