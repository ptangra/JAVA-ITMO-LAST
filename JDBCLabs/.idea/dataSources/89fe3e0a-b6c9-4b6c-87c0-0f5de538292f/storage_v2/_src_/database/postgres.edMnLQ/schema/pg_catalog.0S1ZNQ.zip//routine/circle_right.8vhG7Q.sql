CREATE FUNCTION circle_right(circle, circle)
  RETURNS boolean
AS $$
circle_right
$$;

