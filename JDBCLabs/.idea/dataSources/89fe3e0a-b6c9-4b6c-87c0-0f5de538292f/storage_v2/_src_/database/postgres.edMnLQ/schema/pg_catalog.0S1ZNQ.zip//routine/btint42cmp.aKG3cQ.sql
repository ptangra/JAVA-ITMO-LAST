CREATE FUNCTION btint42cmp(integer, smallint)
  RETURNS integer
AS $$
btint42cmp
$$;

