CREATE FUNCTION bitshiftleft(bit, integer)
  RETURNS bit
AS $$
bitshiftleft
$$;

