CREATE FUNCTION byteacat(bytea, bytea)
  RETURNS bytea
AS $$
byteacat
$$;

