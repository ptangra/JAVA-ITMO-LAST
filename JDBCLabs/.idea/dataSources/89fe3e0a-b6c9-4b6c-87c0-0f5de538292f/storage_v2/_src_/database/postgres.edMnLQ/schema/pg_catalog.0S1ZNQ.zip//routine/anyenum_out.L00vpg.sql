CREATE FUNCTION anyenum_out(anyenum)
  RETURNS cstring
AS $$
anyenum_out
$$;

