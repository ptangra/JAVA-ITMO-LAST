CREATE FUNCTION bitge(bit, bit)
  RETURNS boolean
AS $$
bitge
$$;

