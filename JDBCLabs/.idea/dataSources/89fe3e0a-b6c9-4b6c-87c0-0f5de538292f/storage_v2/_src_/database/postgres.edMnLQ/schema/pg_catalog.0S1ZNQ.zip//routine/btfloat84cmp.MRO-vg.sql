CREATE FUNCTION btfloat84cmp(double precision, real)
  RETURNS integer
AS $$
btfloat84cmp
$$;

