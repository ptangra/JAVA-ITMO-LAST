CREATE FUNCTION brin_inclusion_opcinfo(internal)
  RETURNS internal
AS $$
brin_inclusion_opcinfo
$$;

