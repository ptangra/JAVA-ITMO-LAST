CREATE FUNCTION box_gt(box, box)
  RETURNS boolean
AS $$
box_gt
$$;

