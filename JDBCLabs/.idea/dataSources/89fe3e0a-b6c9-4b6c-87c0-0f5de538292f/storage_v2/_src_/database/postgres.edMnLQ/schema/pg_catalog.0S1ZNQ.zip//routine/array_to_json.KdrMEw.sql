CREATE FUNCTION array_to_json(anyarray)
  RETURNS json
AS $$
array_to_json
$$;

