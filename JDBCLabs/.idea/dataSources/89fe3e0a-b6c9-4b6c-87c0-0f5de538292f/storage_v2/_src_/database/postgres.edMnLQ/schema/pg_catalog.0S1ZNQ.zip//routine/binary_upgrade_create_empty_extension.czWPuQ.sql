CREATE FUNCTION binary_upgrade_create_empty_extension(text, text, boolean, text, oid[], text[], text[])
  RETURNS void
AS $$
binary_upgrade_create_empty_extension
$$;

