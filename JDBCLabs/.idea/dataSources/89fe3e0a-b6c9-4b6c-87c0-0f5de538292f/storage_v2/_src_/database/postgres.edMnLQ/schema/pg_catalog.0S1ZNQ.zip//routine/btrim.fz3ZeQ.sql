CREATE FUNCTION btrim(text, text)
  RETURNS text
AS $$
btrim
$$;

