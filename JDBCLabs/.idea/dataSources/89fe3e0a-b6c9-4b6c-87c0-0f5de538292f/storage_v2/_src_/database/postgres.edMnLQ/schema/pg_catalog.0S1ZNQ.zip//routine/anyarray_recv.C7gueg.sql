CREATE FUNCTION anyarray_recv(internal)
  RETURNS anyarray
AS $$
anyarray_recv
$$;

