CREATE FUNCTION boolgt(boolean, boolean)
  RETURNS boolean
AS $$
boolgt
$$;

