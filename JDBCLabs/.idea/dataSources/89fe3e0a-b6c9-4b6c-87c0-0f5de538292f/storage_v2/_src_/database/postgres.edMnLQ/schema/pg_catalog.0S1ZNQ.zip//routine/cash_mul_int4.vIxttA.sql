CREATE FUNCTION cash_mul_int4(money, integer)
  RETURNS money
AS $$
cash_mul_int4
$$;

