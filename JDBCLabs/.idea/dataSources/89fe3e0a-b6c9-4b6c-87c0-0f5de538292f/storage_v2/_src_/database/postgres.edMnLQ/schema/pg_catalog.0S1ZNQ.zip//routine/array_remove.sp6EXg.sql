CREATE FUNCTION array_remove(anyarray, anyelement)
  RETURNS anyarray
AS $$
array_remove
$$;

