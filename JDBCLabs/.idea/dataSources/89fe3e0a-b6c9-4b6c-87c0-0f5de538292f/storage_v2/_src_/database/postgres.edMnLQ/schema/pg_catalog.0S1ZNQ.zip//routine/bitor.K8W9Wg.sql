CREATE FUNCTION bitor(bit, bit)
  RETURNS bit
AS $$
bit_or
$$;

