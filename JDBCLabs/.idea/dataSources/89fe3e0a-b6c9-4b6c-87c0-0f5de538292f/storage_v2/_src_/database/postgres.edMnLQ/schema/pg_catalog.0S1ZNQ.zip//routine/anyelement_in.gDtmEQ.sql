CREATE FUNCTION anyelement_in(cstring)
  RETURNS anyelement
AS $$
anyelement_in
$$;

