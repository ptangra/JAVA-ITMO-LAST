CREATE FUNCTION bpcharge(character, character)
  RETURNS boolean
AS $$
bpcharge
$$;

