CREATE FUNCTION charlt("char", "char")
  RETURNS boolean
AS $$
charlt
$$;

