CREATE FUNCTION broadcast(inet)
  RETURNS inet
AS $$
network_broadcast
$$;

