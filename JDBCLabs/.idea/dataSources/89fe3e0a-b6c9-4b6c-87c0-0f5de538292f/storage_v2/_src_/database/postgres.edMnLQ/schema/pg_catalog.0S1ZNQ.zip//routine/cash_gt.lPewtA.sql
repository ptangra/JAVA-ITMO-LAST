CREATE FUNCTION cash_gt(money, money)
  RETURNS boolean
AS $$
cash_gt
$$;

