CREATE FUNCTION big5_to_mic(integer, integer, cstring, internal, integer)
  RETURNS void
AS $$
big5_to_mic
$$;

