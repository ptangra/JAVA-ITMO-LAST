CREATE FUNCTION array_send(anyarray)
  RETURNS bytea
AS $$
array_send
$$;

