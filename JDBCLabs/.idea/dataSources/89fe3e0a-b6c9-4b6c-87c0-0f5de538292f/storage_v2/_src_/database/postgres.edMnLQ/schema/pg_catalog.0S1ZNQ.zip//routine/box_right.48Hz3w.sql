CREATE FUNCTION box_right(box, box)
  RETURNS boolean
AS $$
box_right
$$;

