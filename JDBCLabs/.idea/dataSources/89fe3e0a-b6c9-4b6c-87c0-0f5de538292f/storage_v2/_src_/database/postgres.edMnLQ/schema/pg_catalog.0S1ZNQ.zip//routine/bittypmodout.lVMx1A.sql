CREATE FUNCTION bittypmodout(integer)
  RETURNS cstring
AS $$
bittypmodout
$$;

