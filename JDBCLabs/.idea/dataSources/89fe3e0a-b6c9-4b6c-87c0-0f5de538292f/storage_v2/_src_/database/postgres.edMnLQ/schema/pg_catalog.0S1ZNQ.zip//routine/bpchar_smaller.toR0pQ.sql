CREATE FUNCTION bpchar_smaller(character, character)
  RETURNS character
AS $$
bpchar_smaller
$$;

