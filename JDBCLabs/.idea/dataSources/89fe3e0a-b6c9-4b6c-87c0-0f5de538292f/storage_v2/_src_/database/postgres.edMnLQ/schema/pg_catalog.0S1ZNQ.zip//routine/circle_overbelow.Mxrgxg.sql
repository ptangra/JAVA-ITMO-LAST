CREATE FUNCTION circle_overbelow(circle, circle)
  RETURNS boolean
AS $$
circle_overbelow
$$;

