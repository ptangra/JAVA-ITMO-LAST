CREATE FUNCTION array_upper(anyarray, integer)
  RETURNS integer
AS $$
array_upper
$$;

