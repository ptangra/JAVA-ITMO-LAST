CREATE FUNCTION cidrecv(internal)
  RETURNS cid
AS $$
cidrecv
$$;

