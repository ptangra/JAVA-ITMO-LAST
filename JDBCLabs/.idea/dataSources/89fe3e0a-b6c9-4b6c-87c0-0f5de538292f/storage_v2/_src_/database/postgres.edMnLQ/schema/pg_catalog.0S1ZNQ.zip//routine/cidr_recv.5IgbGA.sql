CREATE FUNCTION cidr_recv(internal)
  RETURNS cidr
AS $$
cidr_recv
$$;

