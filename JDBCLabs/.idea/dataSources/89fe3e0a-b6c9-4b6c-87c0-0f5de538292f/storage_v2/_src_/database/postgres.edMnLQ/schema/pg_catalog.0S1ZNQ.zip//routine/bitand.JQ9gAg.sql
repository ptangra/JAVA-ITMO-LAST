CREATE FUNCTION bitand(bit, bit)
  RETURNS bit
AS $$
bit_and
$$;

