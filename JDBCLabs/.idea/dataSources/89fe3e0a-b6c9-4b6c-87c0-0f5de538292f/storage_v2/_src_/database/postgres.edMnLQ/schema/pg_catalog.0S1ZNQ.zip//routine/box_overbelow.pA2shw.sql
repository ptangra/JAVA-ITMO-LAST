CREATE FUNCTION box_overbelow(box, box)
  RETURNS boolean
AS $$
box_overbelow
$$;

