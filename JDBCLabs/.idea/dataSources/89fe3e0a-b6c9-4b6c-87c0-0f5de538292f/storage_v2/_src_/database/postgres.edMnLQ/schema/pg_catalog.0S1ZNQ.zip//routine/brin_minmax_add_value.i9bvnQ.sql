CREATE FUNCTION brin_minmax_add_value(internal, internal, internal, internal)
  RETURNS boolean
AS $$
brin_minmax_add_value
$$;

