CREATE FUNCTION bpcharlt(character, character)
  RETURNS boolean
AS $$
bpcharlt
$$;

