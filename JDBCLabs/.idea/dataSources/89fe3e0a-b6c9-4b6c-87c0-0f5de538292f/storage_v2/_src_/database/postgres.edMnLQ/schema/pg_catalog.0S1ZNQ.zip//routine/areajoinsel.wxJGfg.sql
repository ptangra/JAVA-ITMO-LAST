CREATE FUNCTION areajoinsel(internal, oid, internal, smallint, internal)
  RETURNS double precision
AS $$
areajoinsel
$$;

