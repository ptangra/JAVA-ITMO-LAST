CREATE FUNCTION bpcharrecv(internal, oid, integer)
  RETURNS character
AS $$
bpcharrecv
$$;

