CREATE FUNCTION btrecordimagecmp(record, record)
  RETURNS integer
AS $$
btrecordimagecmp
$$;

