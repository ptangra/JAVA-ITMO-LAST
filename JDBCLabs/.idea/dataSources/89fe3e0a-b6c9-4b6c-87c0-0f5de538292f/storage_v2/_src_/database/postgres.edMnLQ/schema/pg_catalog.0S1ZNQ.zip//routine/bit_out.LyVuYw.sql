CREATE FUNCTION bit_out(bit)
  RETURNS cstring
AS $$
bit_out
$$;

