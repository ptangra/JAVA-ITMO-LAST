CREATE FUNCTION byteane(bytea, bytea)
  RETURNS boolean
AS $$
byteane
$$;

