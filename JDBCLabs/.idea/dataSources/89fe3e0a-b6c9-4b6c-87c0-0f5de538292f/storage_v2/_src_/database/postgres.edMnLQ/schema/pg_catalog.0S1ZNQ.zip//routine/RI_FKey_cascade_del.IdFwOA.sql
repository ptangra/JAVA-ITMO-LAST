CREATE FUNCTION "RI_FKey_cascade_del"()
  RETURNS trigger
AS $$
RI_FKey_cascade_del
$$;

