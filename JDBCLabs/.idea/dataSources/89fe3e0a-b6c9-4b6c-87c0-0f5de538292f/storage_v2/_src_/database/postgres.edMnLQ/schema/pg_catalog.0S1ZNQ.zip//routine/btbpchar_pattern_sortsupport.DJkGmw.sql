CREATE FUNCTION btbpchar_pattern_sortsupport(internal)
  RETURNS void
AS $$
btbpchar_pattern_sortsupport
$$;

