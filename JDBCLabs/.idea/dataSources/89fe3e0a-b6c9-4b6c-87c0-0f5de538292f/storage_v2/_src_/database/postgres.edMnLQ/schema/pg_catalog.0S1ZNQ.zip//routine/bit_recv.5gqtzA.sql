CREATE FUNCTION bit_recv(internal, oid, integer)
  RETURNS bit
AS $$
bit_recv
$$;

