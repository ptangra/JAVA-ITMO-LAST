CREATE FUNCTION btboolcmp(boolean, boolean)
  RETURNS integer
AS $$
btboolcmp
$$;

