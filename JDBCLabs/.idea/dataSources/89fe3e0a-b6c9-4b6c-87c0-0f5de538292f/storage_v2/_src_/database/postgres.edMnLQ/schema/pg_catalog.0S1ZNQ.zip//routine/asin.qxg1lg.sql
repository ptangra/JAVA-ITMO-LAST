CREATE FUNCTION asin(double precision)
  RETURNS double precision
AS $$
dasin
$$;

