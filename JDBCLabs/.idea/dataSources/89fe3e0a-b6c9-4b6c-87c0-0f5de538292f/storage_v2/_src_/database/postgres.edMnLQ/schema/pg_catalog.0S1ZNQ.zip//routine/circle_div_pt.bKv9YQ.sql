CREATE FUNCTION circle_div_pt(circle, point)
  RETURNS circle
AS $$
circle_div_pt
$$;

