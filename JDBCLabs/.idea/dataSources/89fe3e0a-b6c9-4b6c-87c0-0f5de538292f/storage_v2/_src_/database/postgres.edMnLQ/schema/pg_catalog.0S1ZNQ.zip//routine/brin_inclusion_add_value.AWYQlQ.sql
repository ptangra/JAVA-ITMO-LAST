CREATE FUNCTION brin_inclusion_add_value(internal, internal, internal, internal)
  RETURNS boolean
AS $$
brin_inclusion_add_value
$$;

