CREATE FUNCTION bpcharicregexne(character, text)
  RETURNS boolean
AS $$
texticregexne
$$;

