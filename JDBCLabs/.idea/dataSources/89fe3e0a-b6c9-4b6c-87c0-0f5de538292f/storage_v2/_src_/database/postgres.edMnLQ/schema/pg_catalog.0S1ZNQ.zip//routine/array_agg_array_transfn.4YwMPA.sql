CREATE FUNCTION array_agg_array_transfn(internal, anyarray)
  RETURNS internal
AS $$
array_agg_array_transfn
$$;

