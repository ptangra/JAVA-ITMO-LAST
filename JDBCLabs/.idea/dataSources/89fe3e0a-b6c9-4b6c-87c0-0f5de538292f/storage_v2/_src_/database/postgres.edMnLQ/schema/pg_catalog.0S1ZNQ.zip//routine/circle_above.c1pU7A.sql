CREATE FUNCTION circle_above(circle, circle)
  RETURNS boolean
AS $$
circle_above
$$;

