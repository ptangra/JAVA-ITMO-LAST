CREATE FUNCTION bpchartypmodout(integer)
  RETURNS cstring
AS $$
bpchartypmodout
$$;

