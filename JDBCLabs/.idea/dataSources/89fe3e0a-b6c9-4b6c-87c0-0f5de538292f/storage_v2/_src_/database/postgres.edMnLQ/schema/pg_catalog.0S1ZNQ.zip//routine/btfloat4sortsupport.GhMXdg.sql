CREATE FUNCTION btfloat4sortsupport(internal)
  RETURNS void
AS $$
btfloat4sortsupport
$$;

