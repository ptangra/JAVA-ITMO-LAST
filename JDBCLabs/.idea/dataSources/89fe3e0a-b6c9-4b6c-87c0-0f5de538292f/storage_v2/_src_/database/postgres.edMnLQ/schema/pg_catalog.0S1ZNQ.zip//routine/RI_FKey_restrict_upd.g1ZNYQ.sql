CREATE FUNCTION "RI_FKey_restrict_upd"()
  RETURNS trigger
AS $$
RI_FKey_restrict_upd
$$;

