CREATE FUNCTION center(box)
  RETURNS point
AS $$
box_center
$$;

