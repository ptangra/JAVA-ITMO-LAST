CREATE FUNCTION bitne(bit, bit)
  RETURNS boolean
AS $$
bitne
$$;

