CREATE FUNCTION asinh(double precision)
  RETURNS double precision
AS $$
dasinh
$$;

