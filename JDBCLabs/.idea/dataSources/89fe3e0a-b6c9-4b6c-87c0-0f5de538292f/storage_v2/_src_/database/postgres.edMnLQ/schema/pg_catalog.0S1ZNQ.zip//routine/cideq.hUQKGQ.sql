CREATE FUNCTION cideq(cid, cid)
  RETURNS boolean
AS $$
cideq
$$;

