CREATE FUNCTION byteage(bytea, bytea)
  RETURNS boolean
AS $$
byteage
$$;

