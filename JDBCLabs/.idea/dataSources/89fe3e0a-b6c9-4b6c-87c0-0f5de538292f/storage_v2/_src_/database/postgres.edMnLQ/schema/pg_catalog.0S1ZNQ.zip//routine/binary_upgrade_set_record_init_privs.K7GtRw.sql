CREATE FUNCTION binary_upgrade_set_record_init_privs(boolean)
  RETURNS void
AS $$
binary_upgrade_set_record_init_privs
$$;

