CREATE FUNCTION bitgt(bit, bit)
  RETURNS boolean
AS $$
bitgt
$$;

