CREATE FUNCTION circle_mul_pt(circle, point)
  RETURNS circle
AS $$
circle_mul_pt
$$;

