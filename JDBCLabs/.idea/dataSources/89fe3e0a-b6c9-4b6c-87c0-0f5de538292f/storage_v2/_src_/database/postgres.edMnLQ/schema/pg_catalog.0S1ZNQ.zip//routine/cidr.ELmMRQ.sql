CREATE FUNCTION cidr(inet)
  RETURNS cidr
AS $$
inet_to_cidr
$$;

