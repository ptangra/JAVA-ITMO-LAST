CREATE FUNCTION cash_ne(money, money)
  RETURNS boolean
AS $$
cash_ne
$$;

