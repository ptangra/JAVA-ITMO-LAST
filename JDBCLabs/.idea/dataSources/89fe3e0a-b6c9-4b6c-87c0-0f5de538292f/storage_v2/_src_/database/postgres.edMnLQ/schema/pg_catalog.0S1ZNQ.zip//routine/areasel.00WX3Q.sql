CREATE FUNCTION areasel(internal, oid, internal, integer)
  RETURNS double precision
AS $$
areasel
$$;

