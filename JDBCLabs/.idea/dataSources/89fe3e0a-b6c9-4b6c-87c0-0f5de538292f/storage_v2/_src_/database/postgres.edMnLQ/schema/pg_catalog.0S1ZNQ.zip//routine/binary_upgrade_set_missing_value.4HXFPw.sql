CREATE FUNCTION binary_upgrade_set_missing_value(oid, text, text)
  RETURNS void
AS $$
binary_upgrade_set_missing_value
$$;

