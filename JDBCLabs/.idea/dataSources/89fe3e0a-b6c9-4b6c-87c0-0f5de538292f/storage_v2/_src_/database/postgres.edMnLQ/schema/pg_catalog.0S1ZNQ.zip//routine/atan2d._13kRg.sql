CREATE FUNCTION atan2d(double precision, double precision)
  RETURNS double precision
AS $$
datan2d
$$;

