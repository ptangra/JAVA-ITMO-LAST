CREATE FUNCTION asind(double precision)
  RETURNS double precision
AS $$
dasind
$$;

