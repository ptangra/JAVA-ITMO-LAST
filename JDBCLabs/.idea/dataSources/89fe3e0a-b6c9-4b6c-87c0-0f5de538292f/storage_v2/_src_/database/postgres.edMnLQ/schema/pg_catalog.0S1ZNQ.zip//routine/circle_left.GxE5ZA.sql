CREATE FUNCTION circle_left(circle, circle)
  RETURNS boolean
AS $$
circle_left
$$;

