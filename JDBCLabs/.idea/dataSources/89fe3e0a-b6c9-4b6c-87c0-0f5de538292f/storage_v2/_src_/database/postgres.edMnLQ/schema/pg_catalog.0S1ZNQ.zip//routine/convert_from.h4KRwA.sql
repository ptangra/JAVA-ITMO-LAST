CREATE FUNCTION convert_from(bytea, name)
  RETURNS text
AS $$
pg_convert_from
$$;

