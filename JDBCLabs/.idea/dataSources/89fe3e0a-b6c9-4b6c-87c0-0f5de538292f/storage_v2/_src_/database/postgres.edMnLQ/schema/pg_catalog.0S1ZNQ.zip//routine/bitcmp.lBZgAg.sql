CREATE FUNCTION bitcmp(bit, bit)
  RETURNS integer
AS $$
bitcmp
$$;

