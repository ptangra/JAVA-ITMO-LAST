CREATE FUNCTION anynonarray_in(cstring)
  RETURNS anynonarray
AS $$
anynonarray_in
$$;

