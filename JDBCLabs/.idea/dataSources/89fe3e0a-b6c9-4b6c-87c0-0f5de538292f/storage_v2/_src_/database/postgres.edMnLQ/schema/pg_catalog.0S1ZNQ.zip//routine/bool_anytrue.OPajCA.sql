CREATE FUNCTION bool_anytrue(internal)
  RETURNS boolean
AS $$
bool_anytrue
$$;

