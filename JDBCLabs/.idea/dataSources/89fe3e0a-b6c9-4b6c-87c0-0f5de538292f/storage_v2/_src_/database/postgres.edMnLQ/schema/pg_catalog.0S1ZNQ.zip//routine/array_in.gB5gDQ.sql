CREATE FUNCTION array_in(cstring, oid, integer)
  RETURNS anyarray
AS $$
array_in
$$;

