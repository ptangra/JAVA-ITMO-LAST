CREATE FUNCTION "RI_FKey_check_upd"()
  RETURNS trigger
AS $$
RI_FKey_check_upd
$$;

