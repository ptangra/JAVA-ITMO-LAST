CREATE FUNCTION bool_alltrue(internal)
  RETURNS boolean
AS $$
bool_alltrue
$$;

