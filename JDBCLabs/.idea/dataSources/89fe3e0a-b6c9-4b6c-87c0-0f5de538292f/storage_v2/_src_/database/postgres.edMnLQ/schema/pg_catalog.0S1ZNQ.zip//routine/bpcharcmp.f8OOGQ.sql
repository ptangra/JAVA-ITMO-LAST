CREATE FUNCTION bpcharcmp(character, character)
  RETURNS integer
AS $$
bpcharcmp
$$;

