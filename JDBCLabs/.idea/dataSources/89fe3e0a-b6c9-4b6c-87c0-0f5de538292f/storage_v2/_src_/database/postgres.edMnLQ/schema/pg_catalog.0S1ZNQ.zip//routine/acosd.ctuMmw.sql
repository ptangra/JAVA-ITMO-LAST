CREATE FUNCTION acosd(double precision)
  RETURNS double precision
AS $$
dacosd
$$;

