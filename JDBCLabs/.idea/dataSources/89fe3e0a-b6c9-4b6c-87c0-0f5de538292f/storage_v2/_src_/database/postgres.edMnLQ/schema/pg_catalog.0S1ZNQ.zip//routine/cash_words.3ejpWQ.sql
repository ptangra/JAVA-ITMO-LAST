CREATE FUNCTION cash_words(money)
  RETURNS text
AS $$
cash_words
$$;

