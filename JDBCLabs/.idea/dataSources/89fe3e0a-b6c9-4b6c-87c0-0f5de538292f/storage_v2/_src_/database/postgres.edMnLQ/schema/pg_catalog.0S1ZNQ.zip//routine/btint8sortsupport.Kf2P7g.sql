CREATE FUNCTION btint8sortsupport(internal)
  RETURNS void
AS $$
btint8sortsupport
$$;

